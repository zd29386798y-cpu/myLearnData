def build_event_graph(events):
    nodes = [e for e in events]
    edges = []
    for a, b in zip(events, events[1:]):
        edges.append({"from": a["line_no"], "to": b["line_no"], "type": "sequence"})
    return {"nodes": nodes, "edges": edges}
