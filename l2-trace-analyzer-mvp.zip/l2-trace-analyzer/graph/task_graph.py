def build_task_graph(events):
    tasks = {}
    for e in events:
        task = e.get("task")
        if task:
            tasks.setdefault(task, []).append(e["line_no"])
    return tasks
