import json
import sqlite3
from pathlib import Path

DB = Path("data/l2trace.db")

def init_db():
    DB.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(DB) as con:
        con.executescript(Path("storage/schema.sql").read_text(encoding="utf-8"))

def save_incident(result):
    init_db()
    with sqlite3.connect(DB) as con:
        con.execute(
            "INSERT INTO incidents(result_json) VALUES (?)",
            (json.dumps(result, ensure_ascii=False),),
        )
