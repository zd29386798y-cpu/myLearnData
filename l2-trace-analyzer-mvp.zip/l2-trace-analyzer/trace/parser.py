from pathlib import Path

def parse_trace_file(path: str):
    """Read raw trace lines. Parsing is intentionally conservative in MVP."""
    return Path(path).read_text(encoding="utf-8", errors="replace").splitlines()
