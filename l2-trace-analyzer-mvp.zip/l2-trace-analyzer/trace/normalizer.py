import re

PATTERN = re.compile(
    r"^(?P<timestamp>\S+\s+\S+)\s+"
    r"(?P<task>\S+)\s+"
    r"(?P<event>\S+)"
    r"(?:\s+(?P<message>.*))?$"
)

def normalize_events(lines):
    events = []
    for n, line in enumerate(lines, 1):
        m = PATTERN.match(line.strip())
        if not m:
            events.append({"line_no": n, "raw": line, "parse_status": "unknown"})
            continue
        d = m.groupdict()
        d["line_no"] = n
        d["raw"] = line
        d["parse_status"] = "ok"
        events.append(d)
    return events
