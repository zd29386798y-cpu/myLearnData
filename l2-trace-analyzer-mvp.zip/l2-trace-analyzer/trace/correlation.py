def correlate_events(events, window_ms=1000):
    """MVP: preserve order and attach previous/next event references."""
    out = []
    for i, event in enumerate(events):
        x = dict(event)
        x["prev_line_no"] = events[i-1]["line_no"] if i else None
        x["next_line_no"] = events[i+1]["line_no"] if i + 1 < len(events) else None
        out.append(x)
    return out
