from analysis.incident import analyze_incident
from storage.sqlite import init_db, save_incident
from trace.parser import parse_trace_file
from trace.normalizer import normalize_events
from trace.correlation import correlate_events
from decision.laya import LayaDecisionEngine
from decision.hypotheses import generate_hypotheses
from decision.evaluator import evaluate_hypotheses

def main(trace_path: str):
    init_db()
    raw = parse_trace_file(trace_path)
    events = normalize_events(raw)
    correlated = correlate_events(events)
    incident = analyze_incident(correlated)
    hypotheses = generate_hypotheses(incident, correlated)
    engine = LayaDecisionEngine()
    evaluated = evaluate_hypotheses(engine, incident, hypotheses, correlated)
    result = {"incident": incident, "hypotheses": evaluated}
    save_incident(result)
    return result

if __name__ == "__main__":
    import argparse, pprint
    p = argparse.ArgumentParser()
    p.add_argument("trace")
    args = p.parse_args()
    pprint.pp(main(args.trace))
