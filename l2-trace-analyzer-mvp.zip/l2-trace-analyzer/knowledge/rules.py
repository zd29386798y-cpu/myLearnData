RULES = {
    "TIMEOUT": ["PLC_COMMUNICATION", "TIMING", "MESSAGE_FLOW"],
    "INVALID_DATA": ["DATA_PROBLEM", "TASK_LOGIC"],
    "SEQUENCE_ERROR": ["MESSAGE_FLOW", "TASK_LOGIC", "TIMING"],
    "ERROR": ["TASK_LOGIC", "MIDDLEWARE", "DATA_PROBLEM"],
}

def candidate_categories(event):
    return RULES.get(event, ["UNKNOWN"])
