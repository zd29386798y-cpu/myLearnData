MIDDLEWARE = {}

def get_middleware(name):
    return MIDDLEWARE.get(name)
