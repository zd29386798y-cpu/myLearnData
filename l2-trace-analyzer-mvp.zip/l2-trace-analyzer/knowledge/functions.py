FUNCTIONS = {}

def get_function(name):
    return FUNCTIONS.get(name)
