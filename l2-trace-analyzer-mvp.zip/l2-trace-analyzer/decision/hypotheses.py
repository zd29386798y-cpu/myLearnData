def generate_hypotheses(incident, events):
    event = incident.get("event")
    mapping = {
        "TIMEOUT": [
            "PLC communication failure",
            "Message flow delay",
            "Timing or scheduling problem",
        ],
        "INVALID_DATA": [
            "Invalid or inconsistent input data",
            "Task logic error",
        ],
        "ERROR": [
            "Task internal logic error",
            "Middleware failure",
            "Data problem",
        ],
    }
    return mapping.get(event, ["Unknown root cause"])
