class LayaDecisionEngine:
    """Adapter boundary. Keeps the rest of the system independent of Laya."""

    def __init__(self, model_name=None, subfolder=None):
        self.model = None
        self.model_name = model_name
        self.subfolder = subfolder

    def load(self):
        import laya
        kwargs = {}
        if self.subfolder:
            kwargs["subfolder"] = self.subfolder
        self.model = laya.load(self.model_name or "convaiinnovations/laya", **kwargs)
        return self

    def choice(self, text, options):
        if self.model is None:
            return {"choice": None, "probabilities": {}, "enabled": False}
        question = {"type": "choice", "text": text, "options": options}
        return self.model.evaluate(question)

    def noul(self, text):
        if self.model is None:
            return {"noul": None, "enabled": False}
        question = {"type": "noul", "text": text}
        return self.model.evaluate(question)
