def evaluate_hypotheses(engine, incident, hypotheses, events):
    context = "\n".join(e.get("raw", "") for e in events if e.get("raw"))
    options = [str(h) for h in hypotheses]
    result = engine.choice(
        f"Incident: {incident}\nTrace evidence:\n{context}",
        options,
    )
    return [{"hypothesis": h, "decision": result} for h in hypotheses]
