from trace.normalizer import normalize_events

def test_normalize():
    events = normalize_events(["2026-01-01 10:00:00.000 TaskA TIMEOUT PLC01"])
    assert events[0]["event"] == "TIMEOUT"
