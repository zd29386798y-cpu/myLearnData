from graph.event_graph import build_event_graph

def test_graph():
    events = [{"line_no": 1}, {"line_no": 2}]
    g = build_event_graph(events)
    assert len(g["edges"]) == 1
