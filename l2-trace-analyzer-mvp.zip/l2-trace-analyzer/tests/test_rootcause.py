from analysis.incident import analyze_incident

def test_incident():
    events = [{"line_no": 1, "event": "TIMEOUT", "task": "TaskA"}]
    x = analyze_incident(events)
    assert x["event"] == "TIMEOUT"
