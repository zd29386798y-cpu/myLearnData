def analyze_incident(events):
    priority = {"ALARM": 5, "ERROR": 4, "TIMEOUT": 4, "INVALID_DATA": 4, "SEQUENCE_ERROR": 4}
    candidates = [e for e in events if e.get("event") in priority]
    if not candidates:
        return {"event": None, "status": "no_incident_event"}
    selected = max(candidates, key=lambda e: priority.get(e.get("event"), 0))
    return {
        "event": selected.get("event"),
        "task": selected.get("task"),
        "timestamp": selected.get("timestamp"),
        "line_no": selected.get("line_no"),
        "raw": selected.get("raw"),
    }
