def summarize_root_cause(evaluated):
    return evaluated[0] if evaluated else None
