def build_evidence(events, incident):
    line_no = incident.get("line_no")
    return [
        e for e in events
        if line_no is not None and abs(e.get("line_no", 0) - line_no) <= 10
    ]
