# l2-trace-analyzer

制御サーバーのトレースからトラブル要因を構造化して切り分けるためのMVP骨格。

## 方針

- Trace parsing / correlation / graph construction: deterministic
- Knowledge: functions / middleware / rules
- Decision Engine: Laya adapter
- Analysis: incident / evidence / root cause
- Storage: SQLite
- UI: later FastAPI/HTML

## ディレクトリ

| ファイル | 役割 |
|---|---|
| app.py | 全体オーケストレーション |
| config/config.yaml | 設定 |
| trace/parser.py | 生ログ読込 |
| trace/normalizer.py | ログを共通イベント形式へ変換 |
| trace/correlation.py | 時系列・近接イベント相関 |
| graph/event_graph.py | イベントグラフ |
| graph/task_graph.py | Task単位のグラフ |
| graph/dependency_graph.py | ソース/Message/Data依存グラフ |
| knowledge/functions.py | C関数メタデータ |
| knowledge/middleware.py | Middlewareメタデータ |
| knowledge/rules.py | 決定論的な候補生成ルール |
| decision/laya.py | Layaへの接続境界 |
| decision/hypotheses.py | 原因仮説生成 |
| decision/evaluator.py | 仮説評価 |
| analysis/incident.py | インシデント抽出 |
| analysis/rootcause.py | 原因候補集約 |
| analysis/evidence.py | 根拠抽出 |
| storage/sqlite.py | SQLiteアクセス |
| storage/schema.sql | DB定義 |
| ui/dashboard.py | 表示層境界 |
| tests/* | 単体テスト |

## 最初の実行

```powershell
cd C:\Projects\l2-trace-analyzer
py -3.12 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python -m pytest
```

Layaを使う段階では、既に動作確認済みのLaya環境へ接続し、`decision/laya.py`だけを実装強化する。

## 設計上の重要点

AIはログから事実を作らない。時刻、Task、Message、Function、Middleware、Data dependencyなどは決定論的に抽出し、その構造化された証拠をDecision Engineへ渡す。

将来は以下へ拡張する。

Trace
 -> Event Graph
 -> Task Graph
 -> Message/Data Dependency
 -> Evidence
 -> Candidate Hypotheses
 -> Laya/NanoJev
 -> Investigation Priority
 -> Source/Trace Viewer
