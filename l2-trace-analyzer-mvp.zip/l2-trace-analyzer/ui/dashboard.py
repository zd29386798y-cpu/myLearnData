def render(result):
    """MVP UI adapter; replace with FastAPI/HTML dashboard later."""
    incident = result.get("incident", {})
    return {
        "title": "L2 Trace Analysis",
        "incident": incident,
        "hypotheses": result.get("hypotheses", []),
    }
