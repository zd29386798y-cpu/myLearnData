"""
conversation/context.py

Laya (および将来の他モデル) に渡すコンテキスト文字列を組み立てる。
「会話そのものの管理」と「判定ロジック」を分離するため、
decision 層はこのモジュールが返す文字列だけを受け取り、
Message や DB の存在を一切知らない。
"""
from __future__ import annotations

from typing import List

from .models import Message


class ConversationContext:
    def __init__(self, max_messages: int = 6):
        self.max_messages = max_messages

    def build(self, messages: List[Message]) -> str:
        """直近 N 件を "話者: 発話" の形式で連結したテキストを返す。"""
        recent = messages[-self.max_messages :] if self.max_messages > 0 else messages
        lines = []
        for m in recent:
            speaker = "User" if m.role == "user" else "Assistant"
            lines.append(f"{speaker}: {m.text}")
        return "\n".join(lines)

    def latest_utterance(self, messages: List[Message]) -> str:
        if not messages:
            return ""
        return messages[-1].text
