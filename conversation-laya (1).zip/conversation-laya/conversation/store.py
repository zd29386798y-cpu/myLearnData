"""
conversation/store.py

会話(メッセージ列)の追加・取得を担う。
実データは storage.sqlite.Storage に永続化しつつ、
同一プロセス内ではメモリ上にキャッシュして毎回DBを読みに行かない。
"""
from __future__ import annotations

from typing import Dict, List, TYPE_CHECKING

from .models import Message

if TYPE_CHECKING:
    from storage.sqlite import Storage


class ConversationStore:
    def __init__(self, storage: "Storage"):
        self.storage = storage
        self._cache: Dict[str, List[Message]] = {}

    def add_message(self, conversation_id: str, role: str, text: str) -> Message:
        msg = Message(id=None, conversation_id=conversation_id, role=role, text=text)
        msg.id = self.storage.insert_message(msg)
        self._cache.setdefault(conversation_id, []).append(msg)
        return msg

    def get_messages(self, conversation_id: str) -> List[Message]:
        if conversation_id not in self._cache:
            self._cache[conversation_id] = self.storage.get_messages(conversation_id)
        return self._cache[conversation_id]
