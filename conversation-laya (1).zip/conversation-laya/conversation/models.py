"""
conversation/models.py

会話・判定結果の基本データモデル。
storage 層(SQLite)と decision 層の両方から参照される、共通の型定義。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


@dataclass
class Message:
    """会話中の1発話。"""

    id: Optional[int]
    conversation_id: str
    role: str  # "user" または "assistant"
    text: str
    timestamp: datetime = field(default_factory=_utcnow)


@dataclass
class DecisionRecord:
    """1発話に対する判定結果(永続化用)。"""

    id: Optional[int]
    conversation_id: str
    message_id: Optional[int]
    emotion_label: str
    emotion_confidence: float
    intent_label: str
    intent_confidence: float
    urgency_score: float
    timestamp: datetime = field(default_factory=_utcnow)
