"""
analysis/change_detection.py

emotion trend の変化点・悪化傾向(escalation)を検出する。
将来のL2トレース解析(Trace -> Decision -> Trend -> Anomaly/Change Detection)
と同じ形の構造を、会話ドメインで先に検証する位置づけ。
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import List, Optional

# ラベルの「重さ」。数値の大小そのものに意味を持たせすぎず、
# あくまで「悪化/改善の向き」を比較するための相対指標として使う。
_SEVERITY = {
    "CALM": 0,
    "POSITIVE": 0,
    "UNCERTAIN": 1,
    "WORRIED": 2,
    "SAD": 2,
    "FRUSTRATED": 3,
    "ANGRY": 4,
}


@dataclass
class ChangeEvent:
    changed: bool
    from_label: Optional[str] = None
    to_label: Optional[str] = None
    direction: Optional[str] = None  # "increasing" / "decreasing" / "lateral"


def detect_change(history: List[str]) -> ChangeEvent:
    """直近2件のラベルを比較し、変化の有無と方向を返す。"""
    if len(history) < 2:
        return ChangeEvent(changed=False)

    prev, curr = history[-2], history[-1]
    if prev == curr:
        return ChangeEvent(changed=False)

    prev_sev = _SEVERITY.get(prev, 1)
    curr_sev = _SEVERITY.get(curr, 1)
    if curr_sev > prev_sev:
        direction = "increasing"
    elif curr_sev < prev_sev:
        direction = "decreasing"
    else:
        direction = "lateral"

    return ChangeEvent(changed=True, from_label=prev, to_label=curr, direction=direction)


def detect_escalation(history: List[str], min_run: int = 2) -> bool:
    """
    直近 (min_run + 1) 件が単調に悪化しているか(CALM -> WORRIED -> FRUSTRATED 等)を検出する。
    同値が続くだけ(悪化していない)場合は escalation とみなさない。
    """
    if len(history) < min_run + 1:
        return False

    window = history[-(min_run + 1) :]
    severities = [_SEVERITY.get(h, 1) for h in window]
    non_decreasing = all(b >= a for a, b in zip(severities, severities[1:]))
    return non_decreasing and severities[-1] > severities[0]
