"""
analysis/trend.py

会話1件ごとの emotion ラベル推移を保持する。
単発の判定だけでは分からない「変化」を見るための土台。
"""
from __future__ import annotations

from typing import List


class EmotionTrend:
    def __init__(self):
        self._history: List[str] = []

    def push(self, emotion_label: str) -> None:
        self._history.append(emotion_label)

    @property
    def history(self) -> List[str]:
        return list(self._history)

    def summary(self, window: int = 5) -> List[str]:
        """直近 window 件のラベル列を返す。"""
        if window <= 0:
            return list(self._history)
        return self._history[-window:]
