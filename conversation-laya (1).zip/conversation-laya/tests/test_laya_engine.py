"""
tests/test_laya_engine.py

実際の Laya API (agent.predict(state, questions) -> {"answers": {...}}) の
レスポンス形式を模したモックで、LayaEngine のパース処理(1回の predict() 呼び出しに
emotion/intent/urgency をまとめ、結果をキャッシュする挙動)を検証する。
実モデルはダウンロードせず、モデルロード成功後の挙動だけをテストする。
"""
from decision.laya import LayaEngine, URGENCY_LEVELS


class _MockAgent:
    """agent.predict() の実際のレスポンス形式を模したモック。"""

    def __init__(self):
        self.calls = 0

    def predict(self, state, questions):
        self.calls += 1
        assert "emotion" in questions and "intent" in questions and "urgency" in questions
        return {
            "answers": {
                "emotion": {"choice": "FRUSTRATED", "confidence": 0.82},
                "intent": {"choice": "REQUEST", "confidence": 0.91},
                # 5段階(0..4)の順序尺度の期待値。index=3 -> "high"
                "urgency": {"score": 3.0, "confidence": 0.7},
            }
        }


def _engine_with_mock() -> LayaEngine:
    engine = LayaEngine.__new__(LayaEngine)  # __init__の実モデルロードを回避
    engine.subfolder = "multilingual"
    engine._model = _MockAgent()
    engine._load_error = None
    from decision.laya import _FallbackEngine

    engine._fallback = _FallbackEngine()
    engine._last_context = None
    engine._last_answers = None
    return engine


def test_infer_emotion_parses_mock_response():
    engine = _engine_with_mock()
    label, confidence = engine.infer_emotion("User: 何度やってもうまくいきません。")
    assert label == "FRUSTRATED"
    assert confidence == 0.82


def test_infer_intent_parses_mock_response():
    engine = _engine_with_mock()
    label, confidence = engine.infer_intent("User: 直してください。")
    assert label == "REQUEST"
    assert confidence == 0.91


def test_infer_urgency_normalizes_ordinal_score():
    engine = _engine_with_mock()
    urgency = engine.infer_urgency("User: 何度やってもうまくいきません。")
    # 5段階(0..4)の3 -> 3/4 = 0.75
    assert urgency == 3.0 / (len(URGENCY_LEVELS) - 1)


def test_same_context_reuses_single_predict_call():
    """同一 context_text に対する emotion/intent/urgency の3回の呼び出しが、
    predict() の呼び出し1回に集約されることを確認する。"""
    engine = _engine_with_mock()
    context_text = "User: 何度やってもうまくいきません。"

    engine.infer_emotion(context_text)
    engine.infer_intent(context_text)
    engine.infer_urgency(context_text)

    assert engine._model.calls == 1


def test_different_context_triggers_new_predict_call():
    engine = _engine_with_mock()
    engine.infer_emotion("User: 発話A")
    engine.infer_emotion("User: 発話B")
    assert engine._model.calls == 2
