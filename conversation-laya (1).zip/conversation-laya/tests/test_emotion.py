from decision import emotion
from decision.laya import _FallbackEngine


def test_frustrated_detection():
    engine = _FallbackEngine()
    label, confidence = emotion.analyze_emotion(engine, "User: 何度やってもうまくいきません。")
    assert label == "FRUSTRATED"
    assert confidence > 0


def test_calm_default():
    engine = _FallbackEngine()
    label, _ = emotion.analyze_emotion(engine, "User: 今日は天気がいいですね。")
    assert label == "CALM"


def test_positive_detection():
    engine = _FallbackEngine()
    label, _ = emotion.analyze_emotion(engine, "User: 助かりました、ありがとうございます。")
    assert label == "POSITIVE"
