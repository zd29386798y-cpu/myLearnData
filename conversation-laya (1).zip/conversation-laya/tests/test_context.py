from datetime import datetime, timezone

from conversation.context import ConversationContext
from conversation.models import Message


def _msg(i: int) -> Message:
    return Message(id=i, conversation_id="c1", role="user", text=f"msg{i}", timestamp=datetime.now(timezone.utc))


def test_build_limits_to_max_messages():
    ctx = ConversationContext(max_messages=2)
    messages = [_msg(i) for i in range(5)]
    built = ctx.build(messages)
    assert "msg3" in built
    assert "msg4" in built
    assert "msg0" not in built


def test_build_formats_speaker_prefix():
    ctx = ConversationContext(max_messages=5)
    built = ctx.build([_msg(0)])
    assert built.startswith("User: msg0")


def test_latest_utterance():
    ctx = ConversationContext()
    assert ctx.latest_utterance([_msg(1)]) == "msg1"
    assert ctx.latest_utterance([]) == ""
