from analysis.change_detection import detect_change, detect_escalation
from decision import intent
from decision.laya import _FallbackEngine


def test_request_detection():
    engine = _FallbackEngine()
    label, confidence = intent.analyze_intent(engine, "User: 直してください。")
    assert label == "REQUEST"
    assert confidence > 0


def test_question_detection():
    engine = _FallbackEngine()
    label, _ = intent.analyze_intent(engine, "User: どうしたらいいですか？")
    assert label == "QUESTION"


def test_detect_change_reports_direction():
    change = detect_change(["CALM", "WORRIED"])
    assert change.changed is True
    assert change.direction == "increasing"


def test_detect_change_no_change():
    change = detect_change(["CALM", "CALM"])
    assert change.changed is False


def test_detect_escalation_true_on_monotonic_worsening():
    assert detect_escalation(["CALM", "WORRIED", "FRUSTRATED"], min_run=2) is True


def test_detect_escalation_false_when_improving():
    assert detect_escalation(["FRUSTRATED", "WORRIED", "CALM"], min_run=2) is False
