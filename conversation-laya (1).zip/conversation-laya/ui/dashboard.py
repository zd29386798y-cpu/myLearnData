"""
ui/dashboard.py

Phase 4 相当の簡易ブラウザGUI。
会話を入力すると、その場で emotion/intent/urgency 判定・変化検出を行い、
JSON として返す薄い Flask アプリ。
"""
from __future__ import annotations

from pathlib import Path
from typing import Dict

from flask import Flask, jsonify, render_template, request

_PROJECT_ROOT = Path(__file__).resolve().parent.parent
_TEMPLATE_DIR = _PROJECT_ROOT / "templates"

from analysis.change_detection import detect_change, detect_escalation
from analysis.trend import EmotionTrend
from conversation.context import ConversationContext
from conversation.store import ConversationStore
from decision.evaluator import Evaluator
from decision.laya import build_engine
from storage.sqlite import Storage


def create_app(config: dict) -> Flask:
    app = Flask(__name__, template_folder=str(_TEMPLATE_DIR))

    storage = Storage(config["storage"]["db_path"])
    store = ConversationStore(storage)
    context = ConversationContext(max_messages=config["context"]["max_messages"])
    engine = build_engine(config)
    evaluator = Evaluator(engine)

    trend_window = config["analysis"]["trend_window"]
    escalation_min_run = config["analysis"]["escalation_min_run"]
    trends: Dict[str, EmotionTrend] = {}

    @app.route("/")
    def index():
        engine_status = "loaded" if getattr(engine, "is_loaded", False) else "fallback"
        return render_template("dashboard.html", engine_status=engine_status, engine_name=engine.name)

    @app.route("/api/message", methods=["POST"])
    def post_message():
        data = request.get_json(force=True) or {}
        conversation_id = data.get("conversation_id", "default")
        text = (data.get("text") or "").strip()
        if not text:
            return jsonify({"error": "text is required"}), 400

        msg = store.add_message(conversation_id, role="user", text=text)
        messages = store.get_messages(conversation_id)
        context_text = context.build(messages)

        decision = evaluator.evaluate(context_text)
        storage.insert_decision(conversation_id, msg.id, decision)

        trend = trends.setdefault(conversation_id, EmotionTrend())
        trend.push(decision.emotion_label)
        change = detect_change(trend.history)
        escalating = detect_escalation(trend.history, escalation_min_run)

        return jsonify(
            {
                "text": text,
                "emotion": {"label": decision.emotion_label, "confidence": decision.emotion_confidence},
                "intent": {"label": decision.intent_label, "confidence": decision.intent_confidence},
                "urgency": decision.urgency_score,
                "trend": trend.summary(trend_window),
                "change": {
                    "changed": change.changed,
                    "from": change.from_label,
                    "to": change.to_label,
                    "direction": change.direction,
                },
                "escalating": escalating,
            }
        )

    @app.route("/api/history/<conversation_id>")
    def get_history(conversation_id: str):
        return jsonify(storage.get_decisions(conversation_id))

    return app
