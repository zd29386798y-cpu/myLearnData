"""
storage/sqlite.py

会話・メッセージ・判定結果の永続化を担う薄いラッパー。
「同じ会話を時間経過で再分析する」実験ができるよう、
message と decision を分けて保持している。
"""
from __future__ import annotations

import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, List, Optional

from conversation.models import Message

if TYPE_CHECKING:
    from decision.evaluator import Decision

SCHEMA_PATH = Path(__file__).with_name("schema.sql")


class Storage:
    def __init__(self, db_path: str):
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._init_schema()

    def _init_schema(self) -> None:
        with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
            self._conn.executescript(f.read())
        self._conn.commit()

    def ensure_conversation(self, conversation_id: str) -> None:
        self._conn.execute(
            "INSERT OR IGNORE INTO conversation (id, created_at) VALUES (?, ?)",
            (conversation_id, datetime.now(timezone.utc).isoformat()),
        )
        self._conn.commit()

    def insert_message(self, msg: Message) -> int:
        self.ensure_conversation(msg.conversation_id)
        cur = self._conn.execute(
            "INSERT INTO message (conversation_id, role, text, timestamp) VALUES (?, ?, ?, ?)",
            (msg.conversation_id, msg.role, msg.text, msg.timestamp.isoformat()),
        )
        self._conn.commit()
        return cur.lastrowid

    def get_messages(self, conversation_id: str) -> List[Message]:
        rows = self._conn.execute(
            "SELECT id, conversation_id, role, text, timestamp FROM message "
            "WHERE conversation_id = ? ORDER BY id",
            (conversation_id,),
        ).fetchall()
        return [
            Message(
                id=r["id"],
                conversation_id=r["conversation_id"],
                role=r["role"],
                text=r["text"],
                timestamp=datetime.fromisoformat(r["timestamp"]),
            )
            for r in rows
        ]

    def insert_decision(self, conversation_id: str, message_id: Optional[int], decision: "Decision") -> int:
        cur = self._conn.execute(
            """
            INSERT INTO decision
                (conversation_id, message_id, emotion, emotion_confidence,
                 intent, intent_confidence, urgency, timestamp)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                conversation_id,
                message_id,
                decision.emotion_label,
                decision.emotion_confidence,
                decision.intent_label,
                decision.intent_confidence,
                decision.urgency_score,
                datetime.now(timezone.utc).isoformat(),
            ),
        )
        self._conn.commit()
        return cur.lastrowid

    def get_decisions(self, conversation_id: str) -> List[dict]:
        rows = self._conn.execute(
            "SELECT * FROM decision WHERE conversation_id = ? ORDER BY id",
            (conversation_id,),
        ).fetchall()
        return [dict(r) for r in rows]

    def close(self) -> None:
        self._conn.close()
