# conversation-laya

会話の感情(emotion)・意図(intent)・緊急度(urgency)を判定し、時系列での変化
(escalation)を検出するための MVP。将来、L2トレース解析システムへの応用や、
Laya / NanoJev / Qwen3 など複数の判定モデルの比較実験を見据えた構造にしている。

## ディレクトリ構成

```text
conversation-laya/
├─ app.py                 起動エントリーポイント (demo / ui)
├─ config/
│  └─ config.yaml         モデル・閾値・DBパス等の設定
├─ conversation/           会話そのものの管理
│  ├─ models.py            Message / DecisionRecord
│  ├─ context.py           Laya等に渡すコンテキスト文字列を組み立てる
│  └─ store.py             メッセージの追加・取得(キャッシュ+永続化)
├─ decision/               Layaによる判定
│  ├─ laya.py               Laya への共通アダプタ(未インストール時はフォールバック)
│  ├─ emotion.py             感情判定(将来差し替え可能な独立モジュール)
│  ├─ intent.py               意図判定(同上)
│  └─ evaluator.py            emotion/intent/urgency を統合
├─ analysis/               時系列・変化の分析
│  ├─ trend.py               emotion ラベルの推移を保持
│  └─ change_detection.py    変化点検出・escalation(悪化傾向)検出
├─ storage/                 SQLiteへの保存
│  ├─ sqlite.py
│  └─ schema.sql
├─ ui/
│  └─ dashboard.py          Flask ダッシュボード
├─ templates/
│  └─ dashboard.html        ブラウザGUI(監視パネル風)
├─ tests/                   pytest による内部ロジックの検証
├─ data/                    conversation.db (初回実行時に自動生成)
└─ requirements.txt
```

## セットアップ

```powershell
cd C:\Projects\conversation-laya
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

Laya 本体を使う場合は `pip install laya` でインストールしてください。実際のAPIは
`agent = laya.load("convaiinnovations/laya", subfolder=...)` の後、
`agent.predict(state, questions)` を1回呼び出して emotion/intent/urgency を
まとめて評価する形式です(`decision/laya.py` の `LayaEngine._predict_all` 参照)。
未インストール、またはロード/推論に失敗した場合は、キーワードベースの
フォールバック実装が自動的に使われるため、モデルなしでも demo / ui / tests は
そのまま動作します。

## 実行方法

### 1. ロジックの検証(まずここから)

```powershell
python -m pytest
```

### 2. コンソールデモ

```powershell
python app.py demo
```

サンプル会話(3発話)を投入し、各発話の emotion / intent / urgency と、
感情の変化・悪化傾向(escalation)をコンソールに表示する。

### 3. ブラウザダッシュボード

```powershell
python app.py ui
```

`http://127.0.0.1:5000` を開くと、会話を入力しながら現在の判定結果と
感情トレンドをリアルタイムに確認できる。

## 設計上のポイント

- **decision/emotion.py と decision/intent.py を分離している**のは、
  将来どちらか一方だけを別モデル(NanoJev, Qwen3 等)に差し替えて比較実験を
  行うことを想定しているため。`config.yaml` の `decision_engine` を切り替える
  ことで、エンジン全体の差し替えも可能。
- **「本当の感情/意図」ではなく「発話から観測できる状態」を分類する**という
  前提を明示している(`decision/laya.py` のコメント参照)。断定的な解釈はしない。
- **SQLite に conversation / message / decision を分けて保存**することで、
  同じ会話を後から再分析する実験ができるようにしている。
- `analysis/` の構造は、将来の L2 トレース解析
  (`Trace → Decision → Trend → Anomaly/Change Detection`) にそのまま
  応用できる形にしている。

## 今後の拡張(Phase 3以降)

- `decision/` に `nanojev.py` / `qwen.py` などを追加し、`evaluator.py` で
  複数エンジンの結果を比較する。
- `Noul`(現在未実装)を評価軸に追加し、`Conversation State` として統合する。
- `multilingual` と `typed-decisions` サブフォルダの精度比較。
