"""
app.py

conversation-laya エントリーポイント。

使い方:
    python app.py demo   # サンプル会話を投入し、判定結果と変化検出をコンソール表示
    python app.py ui     # Flask ダッシュボードを起動 (http://127.0.0.1:5000)
"""
from __future__ import annotations

import sys

import yaml

from analysis.change_detection import detect_change, detect_escalation
from analysis.trend import EmotionTrend
from conversation.context import ConversationContext
from conversation.store import ConversationStore
from decision.evaluator import Evaluator
from decision.laya import build_engine
from storage.sqlite import Storage

DEMO_UTTERANCES = [
    "最近ちょっと困っています。",
    "何度やってもうまくいきません。",
    "どうしたらいいですか？",
]


def load_config(path: str = "config/config.yaml") -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def build_app(config: dict):
    storage = Storage(config["storage"]["db_path"])
    store = ConversationStore(storage)
    context = ConversationContext(max_messages=config["context"]["max_messages"])
    engine = build_engine(config)
    evaluator = Evaluator(engine)
    return storage, store, context, engine, evaluator


def run_demo() -> None:
    config = load_config()
    storage, store, context, engine, evaluator = build_app(config)
    conversation_id = "demo-001"
    trend = EmotionTrend()

    engine_status = (
        "Laya モデル読み込み済み"
        if getattr(engine, "is_loaded", False)
        else "フォールバック実装で動作中 (laya 未インストール、またはロード失敗)"
    )
    print(f"[decision engine: {engine.name}] {engine_status}\n")

    for text in DEMO_UTTERANCES:
        msg = store.add_message(conversation_id, role="user", text=text)
        messages = store.get_messages(conversation_id)
        context_text = context.build(messages)

        decision = evaluator.evaluate(context_text)
        storage.insert_decision(conversation_id, msg.id, decision)
        trend.push(decision.emotion_label)

        change = detect_change(trend.history)
        escalating = detect_escalation(trend.history, config["analysis"]["escalation_min_run"])

        print(f"発話: {text}")
        print(f"  emotion  : {decision.emotion_label} ({decision.emotion_confidence:.2f})")
        print(f"  intent   : {decision.intent_label} ({decision.intent_confidence:.2f})")
        print(f"  urgency  : {decision.urgency_score:.2f}")
        if change.changed:
            print(f"  change   : {change.from_label} -> {change.to_label} ({change.direction})")
        if escalating:
            print("  ALERT    : 感情が悪化傾向にあります")
        print()

    storage.close()


def run_ui() -> None:
    config = load_config()
    from ui.dashboard import create_app

    flask_app = create_app(config)
    flask_app.run(
        host=config["ui"]["host"],
        port=config["ui"]["port"],
        debug=config["ui"]["debug"],
    )


if __name__ == "__main__":
    command = sys.argv[1] if len(sys.argv) > 1 else "demo"
    if command == "demo":
        run_demo()
    elif command == "ui":
        run_ui()
    else:
        print("使い方: python app.py [demo|ui]")
