"""
decision/laya.py

Laya (https://github.com/convaiinnovations/laya, PyPI: `laya`) への共通インターフェース。

実際のAPI (2026-09 時点):
    import laya
    agent = laya.load("convaiinnovations/laya", subfolder="multilingual")
    result = agent.predict(state, questions)
    answers = result["answers"]
    answers["<key>"]["choice"]      # choice 型: 選択されたラベル
    answers["<key>"]["score"]       # score 型: criteria(順序尺度)上の期待値
    answers["<key>"]["confidence"]  # 各型共通の確信度

`questions` は {質問キー: {"type": "choice"|"score"|"noul", "instructions": str,
"criteria": dict(choice用: ラベル->説明) | list(score用: 順序尺度のラベル列)}} の形式。
1回の predict() 呼び出しで複数の質問をまとめて評価できるため、
本アダプタは emotion/intent/urgency の3問を1回の forward pass にまとめている
(_predict_all の結果を同一 context_text の間だけキャッシュする)。

設計方針:
- emotion / intent / urgency を「独立したメソッド」として公開する。
  これにより、将来 emotion だけ NanoJev や Qwen3 に差し替える、といった
  比較実験を decision/emotion.py 側の変更だけで完結させられる。
- laya パッケージが未インストール、モデルのロードに失敗した場合、
  または predict() 呼び出し自体が失敗した場合は、キーワードベースの
  フォールバック実装に自動委譲する。これにより、モデルなしの環境でも
  app.py / tests がそのまま動作する。
"""
from __future__ import annotations

from typing import Any, Dict, Optional, Tuple

EMOTION_CRITERIA: Dict[str, str] = {
    "CALM": "落ち着いている、通常の口調",
    "POSITIVE": "満足・感謝・前向きな口調",
    "WORRIED": "不安や困惑を示す口調",
    "FRUSTRATED": "何度も同じ問題が解決せずいら立っている",
    "ANGRY": "強い怒りを示す口調",
    "SAD": "落胆や悲しみを示す口調",
    "UNCERTAIN": "感情がはっきり読み取れない、あいまいな発話",
}

INTENT_CRITERIA: Dict[str, str] = {
    "QUESTION": "質問をしている",
    "REQUEST": "何かをしてほしいと依頼している",
    "INFORMATION": "単に情報を伝えている",
    "COMPLAINT": "不満や苦情を述べている",
    "CONFIRMATION": "内容の確認をしている",
    "REFUSAL": "依頼や提案を断っている",
    "APOLOGY": "謝罪している",
    "THANKS": "感謝を伝えている",
    "OTHER": "上記のいずれにも当てはまらない",
}

# score型は「順序尺度」の期待値(0 〜 len-1)を返す想定のため、後で 0.0-1.0 に正規化する。
URGENCY_LEVELS = ["not_urgent", "low", "medium", "high", "critical"]

EMOTION_LABELS = list(EMOTION_CRITERIA.keys())
INTENT_LABELS = list(INTENT_CRITERIA.keys())


def _last_utterance(context_text: str) -> str:
    """"話者: 発話" 形式のコンテキストから最後の発話部分だけを取り出す。"""
    lines = [l for l in context_text.splitlines() if l.strip()]
    if not lines:
        return ""
    last = lines[-1]
    return last.split(": ", 1)[1] if ": " in last else last


class BaseDecisionEngine:
    """全ての判定エンジン(Laya/フォールバック/将来の他モデル)が実装するインターフェース。"""

    name = "base"

    def infer_emotion(self, context_text: str) -> Tuple[str, float]:
        raise NotImplementedError

    def infer_intent(self, context_text: str) -> Tuple[str, float]:
        raise NotImplementedError

    def infer_urgency(self, context_text: str) -> float:
        raise NotImplementedError


class _FallbackEngine(BaseDecisionEngine):
    """laya が使えない環境向けの簡易キーワード判定(開発・テスト専用)。"""

    name = "fallback"

    _EMOTION_KEYWORDS = {
        "FRUSTRATED": ["何度", "何回", "うまくいかない", "うまくいきません", "もう無理", "直りません", "だめ", "ダメ"],
        "ANGRY": ["怒", "ふざけるな", "最悪"],
        "WORRIED": ["困って", "心配", "不安"],
        "SAD": ["悲しい", "つらい", "残念"],
        "POSITIVE": ["ありがとう", "助かりました", "嬉しい", "よかった"],
    }
    _INTENT_KEYWORDS = {
        "QUESTION": ["ですか", "でしょうか", "？", "?"],
        "REQUEST": ["ください", "お願いします", "してほしい"],
        "COMPLAINT": ["おかしい", "不具合", "バグ"],
        "THANKS": ["ありがとう", "感謝"],
        "APOLOGY": ["すみません", "申し訳"],
    }
    _URGENCY_BY_EMOTION = {
        "FRUSTRATED": 0.75,
        "ANGRY": 0.85,
        "WORRIED": 0.55,
        "SAD": 0.45,
    }

    def infer_emotion(self, context_text: str) -> Tuple[str, float]:
        text = _last_utterance(context_text)
        return self._match(text, self._EMOTION_KEYWORDS, default="CALM")

    def infer_intent(self, context_text: str) -> Tuple[str, float]:
        text = _last_utterance(context_text)
        return self._match(text, self._INTENT_KEYWORDS, default="OTHER")

    def infer_urgency(self, context_text: str) -> float:
        emotion_label, _ = self.infer_emotion(context_text)
        return self._URGENCY_BY_EMOTION.get(emotion_label, 0.3)

    @staticmethod
    def _match(text: str, table: dict, default: str) -> Tuple[str, float]:
        for label, keywords in table.items():
            for kw in keywords:
                if kw in text:
                    return label, 0.6
        return default, 0.4


class LayaEngine(BaseDecisionEngine):
    """実際の Laya モデルを使う判定エンジン。"""

    name = "laya"

    def __init__(self, subfolder: str = "multilingual"):
        self.subfolder = subfolder
        self._model = None
        self._load_error: Optional[str] = None
        self._fallback = _FallbackEngine()
        self._last_context: Optional[str] = None
        self._last_answers: Optional[Dict[str, Any]] = None
        self._try_load()

    def _try_load(self) -> None:
        try:
            import laya  # type: ignore

            self._model = laya.load("convaiinnovations/laya", subfolder=self.subfolder)
        except Exception as exc:  # noqa: BLE001 - ImportError, HFダウンロード失敗等を包括的に捕捉
            self._load_error = str(exc)
            self._model = None

    @property
    def is_loaded(self) -> bool:
        return self._model is not None

    @property
    def load_error(self) -> Optional[str]:
        return self._load_error

    def _questions(self) -> Dict[str, Any]:
        return {
            "emotion": {
                "type": "choice",
                "instructions": "直近の発話から観測できる感情表現を分類してください。",
                "criteria": EMOTION_CRITERIA,
            },
            "intent": {
                "type": "choice",
                "instructions": "直近の発話の意図を分類してください。",
                "criteria": INTENT_CRITERIA,
            },
            "urgency": {
                "type": "score",
                "instructions": "直近の発話の緊急度を評価してください。",
                "criteria": URGENCY_LEVELS,
            },
        }

    def _predict_all(self, context_text: str) -> Optional[Dict[str, Any]]:
        """1回の predict() 呼び出しで emotion/intent/urgency をまとめて評価し、
        同一 context_text の間はキャッシュして再利用する。失敗時は None を返す。"""
        if self._last_context == context_text and self._last_answers is not None:
            return self._last_answers
        try:
            result = self._model.predict(context_text, self._questions())
            answers = result["answers"]
        except Exception as exc:  # noqa: BLE001 - predict() 側の形式差異・実行時エラーを包括的に捕捉
            self._load_error = str(exc)
            return None
        self._last_context = context_text
        self._last_answers = answers
        return answers

    def infer_emotion(self, context_text: str) -> Tuple[str, float]:
        if not self.is_loaded:
            return self._fallback.infer_emotion(context_text)
        answers = self._predict_all(context_text)
        if answers is None:
            return self._fallback.infer_emotion(context_text)
        a = answers["emotion"]
        return a["choice"], float(a.get("confidence", 0.0))

    def infer_intent(self, context_text: str) -> Tuple[str, float]:
        if not self.is_loaded:
            return self._fallback.infer_intent(context_text)
        answers = self._predict_all(context_text)
        if answers is None:
            return self._fallback.infer_intent(context_text)
        a = answers["intent"]
        return a["choice"], float(a.get("confidence", 0.0))

    def infer_urgency(self, context_text: str) -> float:
        if not self.is_loaded:
            return self._fallback.infer_urgency(context_text)
        answers = self._predict_all(context_text)
        if answers is None:
            return self._fallback.infer_urgency(context_text)
        a = answers["urgency"]
        raw = float(a["score"])
        levels = len(URGENCY_LEVELS)
        normalized = raw / (levels - 1) if levels > 1 else raw
        return max(0.0, min(1.0, normalized))


def build_engine(config: dict) -> BaseDecisionEngine:
    """config["decision_engine"] に応じたエンジンを構築する。"""
    engine_name = config.get("decision_engine", "laya")
    if engine_name == "laya":
        subfolder = config.get("laya", {}).get("subfolder", "multilingual")
        return LayaEngine(subfolder=subfolder)
    if engine_name == "fallback":
        return _FallbackEngine()
    raise ValueError(f"未対応の decision_engine: {engine_name}")
