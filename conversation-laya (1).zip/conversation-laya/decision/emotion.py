"""
decision/emotion.py

感情判定"だけ"の責務を持つモジュール。

将来、感情判定だけ Qwen3 など別モデルに差し替えたくなった場合、
この関数の中身(または engine の実装)を変えるだけで済み、
intent.py / evaluator.py / analysis 層には一切手を入れない。
"""
from __future__ import annotations

from typing import Tuple

from .laya import BaseDecisionEngine


def analyze_emotion(engine: BaseDecisionEngine, context_text: str) -> Tuple[str, float]:
    """会話コンテキストから (emotion_label, confidence) を返す。"""
    return engine.infer_emotion(context_text)
