"""
decision/evaluator.py

emotion / intent / urgency の各判定を束ねて1つの Decision にまとめる。
Phase 3 で Noul や複数エンジンの比較(evaluator による統合)を
追加する際も、ここが唯一の集約点になる。
"""
from __future__ import annotations

from dataclasses import dataclass

from . import emotion as emotion_mod
from . import intent as intent_mod
from .laya import BaseDecisionEngine


@dataclass
class Decision:
    emotion_label: str
    emotion_confidence: float
    intent_label: str
    intent_confidence: float
    urgency_score: float


class Evaluator:
    def __init__(self, engine: BaseDecisionEngine):
        self.engine = engine

    def evaluate(self, context_text: str) -> Decision:
        emotion_label, emotion_confidence = emotion_mod.analyze_emotion(self.engine, context_text)
        intent_label, intent_confidence = intent_mod.analyze_intent(self.engine, context_text)
        urgency_score = self.engine.infer_urgency(context_text)
        return Decision(
            emotion_label=emotion_label,
            emotion_confidence=emotion_confidence,
            intent_label=intent_label,
            intent_confidence=intent_confidence,
            urgency_score=urgency_score,
        )
