"""
decision/intent.py

意図判定"だけ"の責務を持つモジュール。emotion.py と対称的な構造にしている。

注意: ここで判定するのは「本当の意図」ではなく、
「発話がこの意図として解釈できる」という発話状態の分類である。
"""
from __future__ import annotations

from typing import Tuple

from .laya import BaseDecisionEngine


def analyze_intent(engine: BaseDecisionEngine, context_text: str) -> Tuple[str, float]:
    """会話コンテキストから (intent_label, confidence) を返す。"""
    return engine.infer_intent(context_text)
