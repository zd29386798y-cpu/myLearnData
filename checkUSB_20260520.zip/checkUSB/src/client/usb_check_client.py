from __future__ import annotations

import getpass
import os
import queue
import socket
import sys
import threading
from datetime import datetime
from pathlib import Path
from tkinter import BOTH, DISABLED, END, LEFT, NORMAL, RIGHT, StringVar, Tk, filedialog, messagebox, ttk
from tkinter.scrolledtext import ScrolledText

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from common.config import AppConfig
from common.crypto_util import CryptoService
from common.file_util import UsbCheckFileStore
from common.models import CheckRecord, USBDevice
from common.usb_util import USBSerialCollector


def app_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


APP_DIR = app_dir()


def config_path() -> Path:
    if getattr(sys, "frozen", False):
        preferred = APP_DIR / "USBCheckClient.config.json"
        legacy = APP_DIR / "config.json"
        return preferred if preferred.exists() or not legacy.exists() else legacy
    return APP_DIR / "config.json"


CONFIG_PATH = config_path()


class ClientApp:
    def __init__(self, root: Tk) -> None:
        self.root = root
        self.root.title("USB現品確認ツール")
        self.root.geometry("840x560")
        self.log_queue: queue.Queue[str] = queue.Queue()
        self.config = AppConfig.load(CONFIG_PATH)
        self.log_file = APP_DIR / "logs" / "USBCheckClient.log"
        self.shared_folder_var = StringVar(value=self.config.shared_folder)
        self.status_var = StringVar(value="待機中")
        self.devices: list[USBDevice] = []
        self.running = False
        self._build_ui()
        self.root.after(100, self._drain_log_queue)
        self._refresh_connection_status()

    def _build_ui(self) -> None:
        outer = ttk.Frame(self.root, padding=8)
        outer.pack(fill=BOTH, expand=True)

        path_frame = ttk.LabelFrame(outer, text="保存先")
        path_frame.pack(fill="x", pady=(0, 6))
        ttk.Entry(path_frame, textvariable=self.shared_folder_var).pack(side=LEFT, fill="x", expand=True, padx=6, pady=5)
        ttk.Button(path_frame, text="参照", command=self._browse_folder).pack(side=RIGHT, padx=(0, 6), pady=5)

        info_frame = ttk.Frame(outer)
        info_frame.pack(fill="x", pady=(0, 6))
        ttk.Label(info_frame, textvariable=self.status_var).pack(side=LEFT)
        ttk.Button(info_frame, text="USB再読込", command=self.refresh_usb_list).pack(side=RIGHT)

        self.device_tree = ttk.Treeview(
            outer,
            columns=("serial", "drive", "filesystem", "label", "media", "model", "method"),
            show="headings",
            height=6,
        )
        for key, label, width in [
            ("serial", "USBシリアル", 150),
            ("drive", "ドライブ", 80),
            ("filesystem", "ファイルシステム", 110),
            ("label", "ボリューム", 120),
            ("media", "メディア種別", 130),
            ("model", "モデル", 180),
            ("method", "取得方式", 110),
        ]:
            self.device_tree.heading(key, text=label)
            self.device_tree.column(key, width=width, anchor="w")
        self.device_tree.pack(fill="x", pady=(0, 6))

        button_frame = ttk.Frame(outer)
        button_frame.pack(fill="x", pady=(0, 6))
        self.run_button = ttk.Button(button_frame, text="実行", command=self.run_check)
        self.run_button.pack(side=LEFT)
        ttk.Button(button_frame, text="終了", command=self.root.destroy).pack(side=RIGHT)

        log_frame = ttk.LabelFrame(outer, text="ログ")
        log_frame.pack(fill=BOTH, expand=True)
        self.log_text = ScrolledText(log_frame, height=12, state=DISABLED, wrap="word")
        self.log_text.pack(fill=BOTH, expand=True, padx=6, pady=6)

    def _browse_folder(self) -> None:
        folder = filedialog.askdirectory(initialdir=self.shared_folder_var.get() or ".")
        if folder:
            self.shared_folder_var.set(folder)
            self.config.shared_folder = folder
            self.config.save(CONFIG_PATH)
            self._refresh_connection_status()

    def _log(self, message: str, debug: bool = False) -> None:
        stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        level = "DEBUG" if debug else "INFO"
        line = f"[{stamp}] [{level}] {message}"
        try:
            self.log_file.parent.mkdir(parents=True, exist_ok=True)
            with self.log_file.open("a", encoding="utf-8") as f:
                f.write(line + "\n")
        except Exception:
            pass
        if (not debug) or self.config.debug_mode:
            self.log_queue.put(f"[{stamp[-8:]}] {message}")

    def _drain_log_queue(self) -> None:
        while True:
            try:
                message = self.log_queue.get_nowait()
            except queue.Empty:
                break
            self.log_text.configure(state=NORMAL)
            self.log_text.insert(END, message + "\n")
            self.log_text.see(END)
            self.log_text.configure(state=DISABLED)
        self.root.after(100, self._drain_log_queue)

    def _refresh_connection_status(self) -> None:
        folder = Path(self.shared_folder_var.get())
        try:
            UsbCheckFileStore(folder).check_write_access()
            self.status_var.set(f"保存先: 接続OK - {folder}")
        except Exception as exc:
            self.status_var.set(f"保存先: 接続不可 - {folder} ({exc})")

    def refresh_usb_list(self) -> None:
        if self.running:
            return
        self.running = True
        self.run_button.configure(state=DISABLED)
        threading.Thread(target=self._refresh_usb_worker, daemon=True).start()

    def _refresh_usb_worker(self) -> None:
        try:
            self._log("USBストレージ一覧を取得します。")
            collector = USBSerialCollector(self._log)
            devices = collector.collect()
            self.root.after(0, lambda: self._set_devices(devices))
        finally:
            self.root.after(0, self._unlock)

    def _set_devices(self, devices: list[USBDevice]) -> None:
        self.devices = devices
        for item in self.device_tree.get_children():
            self.device_tree.delete(item)
        for device in devices:
            self.device_tree.insert(
                "",
                END,
                values=(
                    device.serial,
                    device.drive_letter,
                    device.filesystem,
                    device.volume_label,
                    device.media_type,
                    device.model,
                    device.source_method,
                ),
            )

    def _unlock(self) -> None:
        self.running = False
        self.run_button.configure(state=NORMAL)

    def _short_serial(self, serial: str) -> str:
        return serial[-4:] if len(serial) >= 4 else serial

    def _format_partitions(self, device: USBDevice) -> str:
        if not device.partitions:
            return ""
        return ", ".join(
            f"{partition.get('drive_letter', '')}:({partition.get('filesystem', '')})"
            for partition in device.partitions
            if partition.get("drive_letter")
        )

    def _log_multiple_usb_error(self, devices: list[USBDevice]) -> None:
        self._log("USBメモリが複数検出されました。現品確認ではUSBメモリを1本のみ接続してください。")
        for index, device in enumerate(devices, start=1):
            serial_tail = self._short_serial(device.serial) or "不明"
            self._log(
                f"検出USB {index}: partitions={self._format_partitions(device) or '不明'}, "
                f"volume_label={device.volume_label or '不明'}, "
                f"media_type={device.media_type or '不明'}, "
                f"serial_tail={serial_tail}"
            )

    def run_check(self) -> None:
        if self.running:
            return
        self.config.shared_folder = self.shared_folder_var.get()
        self.config.save(CONFIG_PATH)
        self.running = True
        self.run_button.configure(state=DISABLED)
        threading.Thread(target=self._run_check_worker, daemon=True).start()

    def _run_check_worker(self) -> None:
        try:
            self._log("現品確認を開始します。")
            self._log("USBストレージ一覧を取得します。")
            collector = USBSerialCollector(self._log)
            devices = collector.collect()
            self.root.after(0, lambda: self._set_devices(devices))

            if len(devices) == 0:
                return
            if len(devices) > 1:
                self._log_multiple_usb_error(devices)
                return

            device = devices[0]
            crypto = CryptoService(self.config.app_pepper)
            primary_store = UsbCheckFileStore(self.config.shared_folder)
            fallback_store = UsbCheckFileStore(self.config.local_fallback_folder)
            now = datetime.now()
            checked_date = now.strftime("%Y%m%d")
            checked_at = now.strftime("%Y-%m-%d %H:%M:%S")

            try:
                primary_store.check_write_access()
                store = primary_store
                self._log(f"共有フォルダへ保存します: {primary_store.folder}")
            except Exception as exc:
                store = fallback_store
                self._log(f"共有フォルダへ保存できません: {exc}")
                self._log(f"ローカル退避フォルダへ保存します: {fallback_store.folder}")

            record = CheckRecord(
                user_name=getpass.getuser(),
                computer_name=socket.gethostname(),
                usb_serial=device.serial,
                volume_label=device.volume_label,
                drive_letter=device.drive_letter,
                checked_at=checked_at,
                checked_date=checked_date,
                tool_version=self.config.tool_version,
                model=device.model,
                pnp_device_id=device.pnp_device_id,
                filesystem=device.filesystem,
                media_type=device.media_type,
                drive_type=device.drive_type,
                partitions=self._format_partitions(device),
                source_method=device.source_method,
            )
            encrypted = crypto.encrypt_record(record.to_dict())
            path = store.save_encrypted(device.serial, checked_date, encrypted)
            self._log(f"保存完了: {path}")
            self._log("現品確認が完了しました。")
        except Exception as exc:
            self._log(f"エラー: {exc}")
            self.root.after(0, lambda: messagebox.showerror("エラー", str(exc)))
        finally:
            self.root.after(0, self._unlock)


def main() -> None:
    os.chdir(APP_DIR)
    if "--self-test" in sys.argv:
        import tkinter

        Path("USBCheckClient.selftest.ok").write_text(f"tkinter {tkinter.TkVersion}\n", encoding="utf-8")
        return
    root = Tk()
    ClientApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
