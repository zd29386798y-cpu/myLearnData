from __future__ import annotations

import csv
import os
import queue
import sys
import threading
from collections import Counter
from datetime import date, datetime
from pathlib import Path
from tkinter import BOTH, DISABLED, END, LEFT, NORMAL, RIGHT, StringVar, Tk, filedialog, messagebox, ttk
from tkinter.scrolledtext import ScrolledText
from typing import Any

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from common.config import AppConfig
from common.crypto_util import CryptoService
from common.file_util import UsbCheckFileStore, decrypt_file


def app_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


APP_DIR = app_dir()


def config_path() -> Path:
    if getattr(sys, "frozen", False):
        preferred = APP_DIR / "USBCheckAdmin.config.json"
        legacy = APP_DIR / "config.json"
        return preferred if preferred.exists() or not legacy.exists() else legacy
    return APP_DIR / "config.json"


CONFIG_PATH = config_path()

STATUS_OK = "確認済"
STATUS_UNREGISTERED = "登録外"
STATUS_MISMATCH = "所有者不一致"
STATUS_NOT_CHECKED = "未確認"

SHEET_SUMMARY = "サマリー"
SHEET_DETAIL = "明細"
SHEET_UNREGISTERED = "登録外"
SHEET_MISMATCH = "所有者不一致"
SHEET_NOT_CHECKED = "未確認"
SHEET_DECRYPT_ERROR = "復号エラー"
SHEET_REGISTRY_CANDIDATE = "登録台帳候補"

HEADER_LABELS = {
    "judge": "判定",
    "usb_serial": "USBシリアル",
    "user_name": "確認ユーザー",
    "registered_user": "登録ユーザー",
    "owner_name": "所有者名",
    "department": "部署",
    "computer_name": "PC名",
    "drive_letter": "ドライブ",
    "drive_type": "ドライブ種別",
    "partitions": "パーティション",
    "volume_label": "ボリュームラベル",
    "filesystem": "ファイルシステム",
    "checked_at": "確認日時",
    "last_checked_at": "最終確認日時",
    "last_checked_date": "最終確認日付",
    "days_since_check": "最終確認からの経過日数",
    "source_method": "取得方式",
    "model": "モデル",
    "media_type": "メディア種別",
    "pnp_device_id": "PNPデバイスID",
    "status": "台帳ステータス",
    "remarks": "備考",
    "file_name": "ファイル名",
    "error": "エラー内容",
}

REGISTRY_CANDIDATE_COLUMNS = [
    "usb_serial",
    "user_name",
    "owner_name",
    "department",
    "status",
    "remarks",
    "last_checked_at",
    "computer_name",
    "volume_label",
    "drive_letter",
    "drive_type",
    "filesystem",
    "model",
    "media_type",
]


class AdminApp:
    def __init__(self, root: Tk) -> None:
        self.root = root
        self.root.title("USB現品確認 集計ツール")
        self.root.geometry("820x540")
        self.config = AppConfig.load(CONFIG_PATH)
        self.log_queue: queue.Queue[str] = queue.Queue()
        self.shared_folder_var = StringVar(value=self.config.shared_folder)
        self.registry_path_var = StringVar(value=self.config.registry_path)
        self.output_folder_var = StringVar(value=self.config.output_folder)
        self.status_var = StringVar(value="待機中")
        self.running = False
        self.last_report_path: Path | None = None
        self.last_registry_path: Path | None = None
        self._build_ui()
        self.root.after(100, self._drain_log_queue)

    def _build_ui(self) -> None:
        outer = ttk.Frame(self.root, padding=8)
        outer.pack(fill=BOTH, expand=True)

        self._path_row(outer, "確認ファイル格納フォルダ", self.shared_folder_var, self._browse_shared)
        self._path_row(outer, "登録台帳CSV", self.registry_path_var, self._browse_registry)
        self._path_row(outer, "出力フォルダ", self.output_folder_var, self._browse_output)

        button_frame = ttk.Frame(outer)
        button_frame.pack(fill="x", pady=(2, 6))
        self.run_button = ttk.Button(button_frame, text="集計実行", command=self.run_aggregate)
        self.run_button.pack(side=LEFT, padx=(0, 6))
        self.generate_registry_button = ttk.Button(button_frame, text="登録台帳生成", command=self.generate_registry)
        self.generate_registry_button.pack(side=LEFT, padx=(0, 6))
        self.open_report_button = ttk.Button(
            button_frame,
            text="レポートを開く",
            command=self.open_report,
            state=DISABLED,
        )
        self.open_report_button.pack(side=LEFT, padx=(0, 6))
        self.open_registry_button = ttk.Button(
            button_frame,
            text="登録台帳を開く",
            command=self.open_registry,
            state=DISABLED,
        )
        self.open_registry_button.pack(side=LEFT, padx=(0, 6))
        ttk.Button(button_frame, text="終了", command=self.root.destroy).pack(side=RIGHT)

        ttk.Label(outer, textvariable=self.status_var).pack(fill="x", pady=(0, 6))

        log_frame = ttk.LabelFrame(outer, text="ログ")
        log_frame.pack(fill=BOTH, expand=True)
        self.log_text = ScrolledText(log_frame, height=12, state=DISABLED, wrap="word")
        self.log_text.pack(fill=BOTH, expand=True, padx=6, pady=6)

    def _path_row(self, parent: ttk.Frame, label: str, variable: StringVar, command) -> None:
        frame = ttk.LabelFrame(parent, text=label)
        frame.pack(fill="x", pady=(0, 6))
        ttk.Entry(frame, textvariable=variable).pack(side=LEFT, fill="x", expand=True, padx=6, pady=5)
        ttk.Button(frame, text="参照", command=command).pack(side=RIGHT, padx=(0, 6), pady=5)

    def _browse_shared(self) -> None:
        self._browse_folder(self.shared_folder_var)

    def _browse_output(self) -> None:
        self._browse_folder(self.output_folder_var)

    def _browse_folder(self, variable: StringVar) -> None:
        folder = filedialog.askdirectory(initialdir=variable.get() or ".")
        if folder:
            variable.set(folder)
            self._save_config()

    def _browse_registry(self) -> None:
        initial = Path(self.registry_path_var.get() or ".")
        path = filedialog.askopenfilename(
            initialdir=str(initial.parent if initial.parent else Path(".")),
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
        )
        if path:
            self.registry_path_var.set(path)
            self._save_config()

    def _save_config(self) -> None:
        self.config.shared_folder = self.shared_folder_var.get()
        self.config.registry_path = self.registry_path_var.get()
        self.config.output_folder = self.output_folder_var.get()
        self.config.save(CONFIG_PATH)

    def _log(self, message: str) -> None:
        stamp = datetime.now().strftime("%H:%M:%S")
        self.log_queue.put(f"[{stamp}] {message}")

    def _drain_log_queue(self) -> None:
        while True:
            try:
                message = self.log_queue.get_nowait()
            except queue.Empty:
                break
            self.log_text.configure(state=NORMAL)
            self.log_text.insert(END, message + "\n")
            self.log_text.see(END)
            self.log_text.configure(state=DISABLED)
        self.root.after(100, self._drain_log_queue)

    def run_aggregate(self) -> None:
        if self.running:
            return
        self._save_config()
        self.running = True
        self.last_report_path = None
        self.open_report_button.configure(state=DISABLED)
        self._set_working_buttons(DISABLED)
        threading.Thread(target=self._aggregate_worker, daemon=True).start()

    def generate_registry(self) -> None:
        if self.running:
            return
        self._save_config()
        self.running = True
        self.last_registry_path = None
        self.open_registry_button.configure(state=DISABLED)
        self._set_working_buttons(DISABLED)
        threading.Thread(target=self._registry_worker, daemon=True).start()

    def open_report(self) -> None:
        self._open_path(self.last_report_path, "レポート")

    def open_registry(self) -> None:
        self._open_path(self.last_registry_path, "登録台帳")

    def _open_path(self, path: Path | None, label: str) -> None:
        if path is None:
            self._log(f"{label}の保存先が未設定です。")
            return
        if not path.exists():
            self._log(f"{label}ファイルが見つかりません: {path}")
            return
        try:
            os.startfile(path)  # type: ignore[attr-defined]
            self._log(f"{label}を開きます: {path}")
        except OSError as exc:
            self._log(f"{label}を開けませんでした。Excelまたは関連アプリの状態を確認してください: {exc}")
        except Exception as exc:
            self._log(f"{label}を開けませんでした: {exc}")

    def _set_working_buttons(self, state: str) -> None:
        self.run_button.configure(state=state)
        self.generate_registry_button.configure(state=state)

    def _aggregate_worker(self) -> None:
        try:
            self._log("集計を開始します。")
            records, decrypt_errors = self._read_check_records()
            for error in decrypt_errors:
                self._log(f"復号失敗: {error.file_name} - {error.error}")

            registry = self._load_registry(Path(self.config.registry_path))
            report_path = self._write_report(records, registry, decrypt_errors)
            self.last_report_path = report_path
            self._log(f"Excel出力完了: {report_path}")
            self.root.after(0, lambda: self.open_report_button.configure(state=NORMAL))
            self.root.after(0, lambda: self.status_var.set(f"完了: {report_path}"))
            self.root.after(0, lambda: messagebox.showinfo("完了", f"集計が完了しました。\n{report_path}"))
        except Exception as exc:
            self._log(f"エラー: {exc}")
            self.root.after(0, lambda: messagebox.showerror("エラー", str(exc)))
        finally:
            self.root.after(0, self._unlock)

    def _registry_worker(self) -> None:
        try:
            self._log("登録台帳生成を開始します。")
            records, decrypt_errors = self._read_check_records()
            rows = self._registry_candidate_rows(records)
            output_folder = Path(self.config.output_folder)
            registry_path = self._write_registry_csv(rows, output_folder)
            self.last_registry_path = registry_path
            self._log(f"登録台帳CSV出力完了: {registry_path}")
            self._log(f"登録台帳候補: {len(rows)}件")
            if decrypt_errors:
                self._log(f"復号失敗ファイルはスキップしました: {len(decrypt_errors)}件")
            self.root.after(0, lambda: self.open_registry_button.configure(state=NORMAL))
            self.root.after(0, lambda: self.status_var.set(f"登録台帳生成完了: {registry_path}"))
        except Exception as exc:
            self._log(f"登録台帳生成エラー: {exc}")
            self.root.after(0, lambda: messagebox.showerror("エラー", str(exc)))
        finally:
            self.root.after(0, self._unlock)

    def _unlock(self) -> None:
        self.running = False
        self._set_working_buttons(NORMAL)

    def _read_check_records(self) -> tuple[list[dict[str, Any]], list[Any]]:
        store = UsbCheckFileStore(self.config.shared_folder)
        files = list(store.iter_check_files())
        self._log(f".usbcheckファイル数: {len(files)}")
        crypto = CryptoService(self.config.app_pepper)
        decrypt_results = [decrypt_file(path, crypto) for path in files]
        records = [result.record for result in decrypt_results if result.ok and result.record]
        decrypt_errors = [result for result in decrypt_results if not result.ok]
        self._log(f"復号成功: {len(records)}件")
        return records, decrypt_errors

    def _load_registry(self, path: Path) -> dict[str, dict[str, str]]:
        if not path.exists():
            self._log(f"登録台帳が見つかりません。空台帳として扱います: {path}")
            return {}
        with path.open("r", encoding="utf-8-sig", newline="") as f:
            rows = list(csv.DictReader(f))
        registry: dict[str, dict[str, str]] = {}
        inactive_count = 0
        for row in rows:
            serial = (row.get("usb_serial") or "").strip().upper()
            if not serial:
                continue
            status = (row.get("status") or "active").strip().lower()
            if status and status != "active":
                inactive_count += 1
                continue
            registry[serial] = row
        self._log(f"登録台帳読込: active {len(registry)}件")
        if inactive_count:
            self._log(f"inactive台帳行は照合対象外にしました: {inactive_count}件")
        return registry

    def _parse_checked_at(self, value: Any) -> datetime | None:
        if isinstance(value, datetime):
            return value
        if not value:
            return None
        text = str(value).strip()
        for fmt in ("%Y-%m-%d %H:%M:%S", "%Y/%m/%d %H:%M:%S", "%Y%m%d%H%M%S"):
            try:
                return datetime.strptime(text, fmt)
            except ValueError:
                continue
        try:
            return datetime.fromisoformat(text)
        except ValueError:
            return None

    def _parse_checked_date(self, value: Any, checked_at: datetime | None) -> date | None:
        if isinstance(value, date) and not isinstance(value, datetime):
            return value
        if value:
            text = str(value).strip()
            for fmt in ("%Y%m%d", "%Y-%m-%d", "%Y/%m/%d"):
                try:
                    return datetime.strptime(text, fmt).date()
                except ValueError:
                    continue
        return checked_at.date() if checked_at else None

    def _days_since(self, checked_at: datetime | None) -> int | None:
        if checked_at is None:
            return None
        return max((datetime.now() - checked_at).days, 0)

    def _enrich_record(self, record: dict[str, Any], registry: dict[str, dict[str, str]]) -> dict[str, Any]:
        enriched = dict(record)
        serial = str(enriched.get("usb_serial") or "").strip().upper()
        registered = registry.get(serial)
        last_checked_at = self._parse_checked_at(enriched.get("checked_at"))
        last_checked_date = self._parse_checked_date(enriched.get("checked_date"), last_checked_at)
        days_since_check = self._days_since(last_checked_at)

        if not registered:
            judge = STATUS_UNREGISTERED
        else:
            checked_user = str(enriched.get("user_name") or "").strip().lower()
            registered_user = str(registered.get("user_name") or "").strip().lower()
            if days_since_check is not None and days_since_check >= self.config.recent_days:
                judge = STATUS_NOT_CHECKED
            elif registered_user and checked_user != registered_user:
                judge = STATUS_MISMATCH
            else:
                judge = STATUS_OK

        enriched["usb_serial"] = serial
        enriched["judge"] = judge
        enriched["last_checked_at"] = last_checked_at
        enriched["last_checked_date"] = last_checked_date
        enriched["days_since_check"] = days_since_check
        return enriched

    def _not_checked_row(self, row: dict[str, str]) -> dict[str, Any]:
        enriched = dict(row)
        enriched["judge"] = STATUS_NOT_CHECKED
        enriched["last_checked_at"] = None
        enriched["last_checked_date"] = None
        enriched["days_since_check"] = None
        return enriched

    def _write_report(
        self,
        records: list[dict[str, Any]],
        registry: dict[str, dict[str, str]],
        decrypt_errors: list[Any],
    ) -> Path:
        output_folder = Path(self.config.output_folder)
        output_folder.mkdir(parents=True, exist_ok=True)
        report_path = output_folder / f"usb_check_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"

        enriched_records = [self._enrich_record(record, registry) for record in records]
        status_order = {STATUS_NOT_CHECKED: 0, STATUS_UNREGISTERED: 1, STATUS_MISMATCH: 2, STATUS_OK: 3}
        enriched_records.sort(
            key=lambda row: (
                status_order.get(str(row.get("judge")), 99),
                row.get("last_checked_at") or datetime.max,
            )
        )

        checked_serials = {str(record.get("usb_serial") or "").strip().upper() for record in enriched_records}
        not_checked = [
            self._not_checked_row(row)
            for serial, row in registry.items()
            if serial not in checked_serials
        ]
        unregistered = [record for record in enriched_records if record["judge"] == STATUS_UNREGISTERED]
        mismatch = [record for record in enriched_records if record["judge"] == STATUS_MISMATCH]
        registry_candidates = self._registry_candidate_rows(records)

        wb = Workbook()
        self._write_summary(wb.active, enriched_records, not_checked, decrypt_errors)
        self._write_records_sheet(wb.create_sheet(SHEET_DETAIL), enriched_records, registry)
        self._write_records_sheet(wb.create_sheet(SHEET_UNREGISTERED), unregistered, registry)
        self._write_records_sheet(wb.create_sheet(SHEET_MISMATCH), mismatch, registry)
        self._write_not_checked_sheet(wb.create_sheet(SHEET_NOT_CHECKED), not_checked)
        self._write_errors_sheet(wb.create_sheet(SHEET_DECRYPT_ERROR), decrypt_errors)
        self._write_registry_candidate_sheet(wb.create_sheet(SHEET_REGISTRY_CANDIDATE), registry_candidates)

        wb.save(report_path)
        return report_path

    def _write_summary(self, ws, records: list[dict[str, Any]], not_checked: list[Any], decrypt_errors: list[Any]) -> None:
        ws.title = SHEET_SUMMARY
        counts = Counter(record["judge"] for record in records)
        rows = [
            ("確認ファイル総数", len(records) + len(decrypt_errors)),
            ("復号成功", len(records)),
            (STATUS_OK, counts[STATUS_OK]),
            (STATUS_UNREGISTERED, counts[STATUS_UNREGISTERED]),
            (STATUS_MISMATCH, counts[STATUS_MISMATCH]),
            (STATUS_NOT_CHECKED, counts[STATUS_NOT_CHECKED] + len(not_checked)),
            ("復号失敗", len(decrypt_errors)),
        ]
        ws.append(["項目", "件数"])
        for row in rows:
            ws.append(row)
        self._style_sheet(ws)

    def _write_records_sheet(self, ws, records: list[dict[str, Any]], registry: dict[str, dict[str, str]]) -> None:
        keys = [
            "judge",
            "usb_serial",
            "user_name",
            "registered_user",
            "owner_name",
            "department",
            "computer_name",
            "drive_letter",
            "drive_type",
            "partitions",
            "volume_label",
            "filesystem",
            "checked_at",
            "last_checked_at",
            "last_checked_date",
            "days_since_check",
            "source_method",
            "model",
            "media_type",
            "pnp_device_id",
        ]
        ws.append([HEADER_LABELS.get(key, key) for key in keys])
        for record in records:
            registered = registry.get(str(record.get("usb_serial") or "").strip().upper(), {})
            values = {
                "judge": record.get("judge", ""),
                "usb_serial": record.get("usb_serial", ""),
                "user_name": record.get("user_name", ""),
                "registered_user": registered.get("user_name", ""),
                "owner_name": registered.get("owner_name", ""),
                "department": registered.get("department", ""),
                "computer_name": record.get("computer_name", ""),
                "drive_letter": record.get("drive_letter", ""),
                "drive_type": record.get("drive_type", ""),
                "partitions": record.get("partitions", ""),
                "volume_label": record.get("volume_label", ""),
                "filesystem": record.get("filesystem", ""),
                "checked_at": record.get("checked_at", ""),
                "last_checked_at": record.get("last_checked_at"),
                "last_checked_date": record.get("last_checked_date"),
                "days_since_check": record.get("days_since_check"),
                "source_method": record.get("source_method", ""),
                "model": record.get("model", ""),
                "media_type": record.get("media_type", ""),
                "pnp_device_id": record.get("pnp_device_id", ""),
            }
            ws.append([values[key] for key in keys])
        self._style_sheet(ws)
        self._format_date_columns(ws, keys)
        self._apply_judge_colors(ws, 1, keys.index("days_since_check") + 1)

    def _write_not_checked_sheet(self, ws, rows: list[dict[str, Any]]) -> None:
        keys = [
            "judge",
            "usb_serial",
            "user_name",
            "owner_name",
            "department",
            "status",
            "remarks",
            "last_checked_at",
            "last_checked_date",
            "days_since_check",
        ]
        ws.append([HEADER_LABELS.get(key, key) for key in keys])
        for row in rows:
            values = {
                "judge": row.get("judge", STATUS_NOT_CHECKED),
                "usb_serial": row.get("usb_serial", ""),
                "user_name": row.get("user_name", ""),
                "owner_name": row.get("owner_name", ""),
                "department": row.get("department", ""),
                "status": row.get("status", ""),
                "remarks": row.get("remarks", ""),
                "last_checked_at": row.get("last_checked_at"),
                "last_checked_date": row.get("last_checked_date"),
                "days_since_check": row.get("days_since_check"),
            }
            ws.append([values[key] for key in keys])
        self._style_sheet(ws)
        self._format_date_columns(ws, keys)
        self._apply_judge_colors(ws, 1, keys.index("days_since_check") + 1)

    def _write_errors_sheet(self, ws, errors: list[Any]) -> None:
        keys = ["file_name", "error"]
        ws.append([HEADER_LABELS.get(key, key) for key in keys])
        for error in errors:
            ws.append([error.file_name, error.error])
        self._style_sheet(ws)

    def _registry_candidate_rows(self, records: list[dict[str, Any]]) -> list[dict[str, Any]]:
        latest_by_serial: dict[str, tuple[datetime | None, dict[str, Any]]] = {}
        for record in records:
            serial = str(record.get("usb_serial") or "").strip().upper()
            if not serial:
                continue
            checked_at = self._parse_checked_at(record.get("checked_at"))
            current = latest_by_serial.get(serial)
            if current and current[0] and checked_at and current[0] >= checked_at:
                continue
            if current and current[0] and checked_at is None:
                continue
            latest_by_serial[serial] = (checked_at, record)

        rows: list[dict[str, Any]] = []
        for serial, (checked_at, record) in latest_by_serial.items():
            rows.append(
                {
                    "usb_serial": serial,
                    "user_name": record.get("user_name", ""),
                    "owner_name": "",
                    "department": "",
                    "status": "active",
                    "remarks": "初回集計から自動生成",
                    "last_checked_at": self._format_datetime_text(checked_at, record.get("checked_at")),
                    "computer_name": record.get("computer_name", ""),
                    "volume_label": record.get("volume_label", ""),
                    "drive_letter": record.get("drive_letter", ""),
                    "drive_type": record.get("drive_type", ""),
                    "filesystem": record.get("filesystem", ""),
                    "model": record.get("model", ""),
                    "media_type": record.get("media_type", ""),
                }
            )
        return sorted(rows, key=lambda row: str(row.get("usb_serial") or ""))

    def _format_datetime_text(self, value: datetime | None, fallback: Any = "") -> str:
        if value:
            return value.strftime("%Y-%m-%d %H:%M:%S")
        return str(fallback or "")

    def _write_registry_csv(self, rows: list[dict[str, Any]], output_folder: Path) -> Path:
        output_folder.mkdir(parents=True, exist_ok=True)
        path = output_folder / f"registry_generated_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
        with path.open("w", encoding="utf-8-sig", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=REGISTRY_CANDIDATE_COLUMNS)
            writer.writeheader()
            for row in rows:
                writer.writerow({key: row.get(key, "") for key in REGISTRY_CANDIDATE_COLUMNS})
        return path

    def _write_registry_candidate_sheet(self, ws, rows: list[dict[str, Any]]) -> None:
        ws.append(REGISTRY_CANDIDATE_COLUMNS)
        for row in rows:
            ws.append([row.get(key, "") for key in REGISTRY_CANDIDATE_COLUMNS])
        self._style_sheet(ws)

    def _style_sheet(self, ws) -> None:
        header_fill = PatternFill("solid", fgColor="D9EAF7")
        for cell in ws[1]:
            cell.font = Font(bold=True)
            cell.fill = header_fill
        for column in ws.columns:
            max_length = max(len(str(cell.value or "")) for cell in column)
            ws.column_dimensions[get_column_letter(column[0].column)].width = min(max(max_length + 2, 12), 60)
        ws.auto_filter.ref = ws.dimensions
        ws.freeze_panes = "A2"

    def _format_date_columns(self, ws, keys: list[str]) -> None:
        formats = {
            "last_checked_at": "yyyy/mm/dd hh:mm:ss",
            "last_checked_date": "yyyy/mm/dd",
            "days_since_check": "0",
        }
        for key, number_format in formats.items():
            if key not in keys:
                continue
            column_index = keys.index(key) + 1
            for row in ws.iter_rows(min_row=2, min_col=column_index, max_col=column_index):
                row[0].number_format = number_format

    def _apply_judge_colors(self, ws, judge_column: int, days_since_column: int | None = None) -> None:
        fills = {
            STATUS_OK: PatternFill("solid", fgColor="C6EFCE"),
            STATUS_UNREGISTERED: PatternFill("solid", fgColor="BDD7EE"),
            STATUS_MISMATCH: PatternFill("solid", fgColor="FCE4D6"),
            STATUS_NOT_CHECKED: PatternFill("solid", fgColor="FFC7CE"),
        }
        overdue_fill = PatternFill("solid", fgColor="FFF2CC")
        for row in ws.iter_rows(min_row=2):
            judge = str(row[judge_column - 1].value or "")
            fill = fills.get(judge)
            if days_since_column is not None:
                days_value = row[days_since_column - 1].value
                if isinstance(days_value, int) and days_value >= self.config.recent_days:
                    fill = overdue_fill
            if fill:
                for cell in row:
                    cell.fill = fill


def main() -> None:
    os.chdir(APP_DIR)
    if "--self-test" in sys.argv:
        import tkinter

        from cryptography.fernet import Fernet
        from openpyxl import Workbook

        _ = Fernet
        _ = Workbook
        Path("USBCheckAdmin.selftest.ok").write_text(f"tkinter {tkinter.TkVersion}\n", encoding="utf-8")
        return
    root = Tk()
    AdminApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
