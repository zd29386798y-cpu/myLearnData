"""Shared utilities for the USB inventory tools."""

