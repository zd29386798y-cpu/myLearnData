from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class USBDevice:
    serial: str
    model: str = ""
    pnp_device_id: str = ""
    device_id: str = ""
    drive_letter: str = ""
    volume_label: str = ""
    filesystem: str = ""
    media_type: str = ""
    drive_type: int | None = None
    partitions: list[dict[str, Any]] = field(default_factory=list)
    source_method: str = ""
    raw: dict[str, Any] = field(default_factory=dict)


@dataclass(slots=True)
class CheckRecord:
    user_name: str
    computer_name: str
    usb_serial: str
    volume_label: str
    drive_letter: str
    checked_at: str
    checked_date: str
    tool_version: str
    model: str = ""
    pnp_device_id: str = ""
    filesystem: str = ""
    media_type: str = ""
    drive_type: int | None = None
    partitions: str = ""
    source_method: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "user_name": self.user_name,
            "computer_name": self.computer_name,
            "usb_serial": self.usb_serial,
            "volume_label": self.volume_label,
            "drive_letter": self.drive_letter,
            "checked_at": self.checked_at,
            "checked_date": self.checked_date,
            "tool_version": self.tool_version,
            "model": self.model,
            "pnp_device_id": self.pnp_device_id,
            "filesystem": self.filesystem,
            "media_type": self.media_type,
            "drive_type": self.drive_type,
            "partitions": self.partitions,
            "source_method": self.source_method,
        }


@dataclass(slots=True)
class DecryptResult:
    file_name: str
    ok: bool
    record: dict[str, Any] | None = None
    error: str = ""
