from __future__ import annotations

import json
import re
import subprocess
from collections.abc import Callable
from typing import Any

from .models import USBDevice


LogFn = Callable[[str, bool], None]


class USBSerialCollector:
    """Collect physical USB storage devices, not logical volumes."""

    EXCLUDED_PNP_PATTERN = r"HID|MOUSE|KEYBOARD|BLUETOOTH|BTH|HEADSET|AUDIO"

    def __init__(self, logger: LogFn | None = None, timeout_seconds: int = 20) -> None:
        self.logger = logger or (lambda message, debug=False: None)
        self.timeout_seconds = timeout_seconds

    def _log(self, message: str, debug: bool = False) -> None:
        self.logger(message, debug)

    def collect(self) -> list[USBDevice]:
        methods = [
            ("Win32_DiskDrive", self._collect_win32_diskdrive),
            ("Win32_PhysicalMedia", self._collect_win32_physicalmedia),
            ("Get-CimInstance", self._collect_get_ciminstance),
            ("PNPDeviceID解析", self._collect_from_pnp_device_id),
        ]
        failures: list[str] = []
        for name, method in methods:
            self._log(f"USBストレージ取得を試行: {name}", debug=True)
            try:
                rows = method()
                devices = self._rows_to_devices(rows, name)
                usable = [device for device in devices if device.serial]
                if usable:
                    self._log(f"{name}: {len(usable)}台のUSBストレージを取得しました。", debug=True)
                    for device in usable:
                        self._log_detected_device(device)
                    return self._dedupe(usable)
                reason = f"{name}: 対象USBストレージを取得できませんでした。"
            except Exception as exc:
                reason = f"{name}: 失敗 - {exc}"
            failures.append(reason)
            self._log(reason, debug=True)

        self._log("対象USBストレージが検出されませんでした。")
        self._log("USBストレージ取得に全方式で失敗しました。理由:", debug=True)
        for reason in failures:
            self._log(f"  {reason}", debug=True)
        return []

    def _log_detected_device(self, device: USBDevice) -> None:
        partition_lines = "\n".join(
            f"  - {partition.get('drive_letter', '')}: {partition.get('filesystem', '')}"
            for partition in device.partitions
        )
        if not partition_lines:
            partition_lines = "  - (なし)"
        self._log(
            "USBストレージを検出しました:\n"
            f"- Model: {device.model or '(不明)'}\n"
            f"- SerialTail: {device.serial[-4:]}\n"
            "- InterfaceType: USB\n"
            f"- MediaType: {device.media_type or '(不明)'}\n"
            "- Partitions:\n"
            f"{partition_lines}"
        )

    def _run_powershell_json(self, script: str) -> list[dict[str, Any]]:
        command = [
            "powershell",
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-Command",
            script,
        ]
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=self.timeout_seconds,
            encoding="utf-8",
            errors="replace",
            creationflags=subprocess.CREATE_NO_WINDOW if hasattr(subprocess, "CREATE_NO_WINDOW") else 0,
        )
        if completed.returncode != 0:
            stderr = completed.stderr.strip() or completed.stdout.strip()
            raise RuntimeError(stderr or f"PowerShell exited with {completed.returncode}")
        output = completed.stdout.strip()
        if not output:
            return []
        data = json.loads(output)
        if isinstance(data, dict):
            return [data]
        if isinstance(data, list):
            return data
        return []

    def _collect_win32_diskdrive(self) -> list[dict[str, Any]]:
        return self._run_powershell_json(self._wmi_storage_script(serial_source="disk"))

    def _collect_win32_physicalmedia(self) -> list[dict[str, Any]]:
        return self._run_powershell_json(self._wmi_storage_script(serial_source="physical"))

    def _collect_get_ciminstance(self) -> list[dict[str, Any]]:
        return self._run_powershell_json(self._cim_storage_script(serial_source="disk"))

    def _collect_from_pnp_device_id(self) -> list[dict[str, Any]]:
        return self._run_powershell_json(self._cim_storage_script(serial_source="pnp"))

    def _wmi_storage_script(self, serial_source: str) -> str:
        script = r"""
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new()
$ErrorActionPreference = 'Stop'
$usePhysicalSerial = __USE_PHYSICAL__
$usePnpSerial = __USE_PNP__
$excludedPnpPattern = '__EXCLUDED_PNP_PATTERN__'
$rows = @()
$media = @()
if ($usePhysicalSerial) {
  $media = Get-WmiObject Win32_PhysicalMedia -ErrorAction SilentlyContinue
}
$disks = Get-WmiObject Win32_DiskDrive -ErrorAction Stop
foreach ($disk in $disks) {
  $interfaceType = [string]$disk.InterfaceType
  $pnp = [string]$disk.PNPDeviceID
  $model = [string]$disk.Model
  $mediaType = [string]$disk.MediaType
  $diskSize = [string]$disk.Size
  $diskDeviceID = [string]$disk.DeviceID

  if ($interfaceType -ne 'USB') {
    $rows += [pscustomobject]@{ Include=$false; ExcludeReason='DiskDrive.InterfaceType が USB ではありません'; Model=$model; InterfaceType=$interfaceType; MediaType=$mediaType; PNPDeviceID=$pnp; DeviceID=$diskDeviceID; DiskSize=$diskSize }
    continue
  }
  if ($pnp -match $excludedPnpPattern) {
    $rows += [pscustomobject]@{ Include=$false; ExcludeReason='PNPDeviceID が HID/MOUSE/KEYBOARD/BLUETOOTH 系です'; Model=$model; InterfaceType=$interfaceType; MediaType=$mediaType; PNPDeviceID=$pnp; DeviceID=$diskDeviceID; DiskSize=$diskSize }
    continue
  }

  $partitions = @(Get-WmiObject -Query "ASSOCIATORS OF {Win32_DiskDrive.DeviceID='$($disk.DeviceID)'} WHERE AssocClass = Win32_DiskDriveToDiskPartition" -ErrorAction SilentlyContinue)
  if ($partitions.Count -eq 0) {
    $rows += [pscustomobject]@{ Include=$false; ExcludeReason='Win32_DiskPartition が存在しません'; Model=$model; InterfaceType=$interfaceType; MediaType=$mediaType; PNPDeviceID=$pnp; DeviceID=$diskDeviceID; DiskSize=$diskSize }
    continue
  }
  foreach ($partition in $partitions) {
    $logicalDisks = @(Get-WmiObject -Query "ASSOCIATORS OF {Win32_DiskPartition.DeviceID='$($partition.DeviceID)'} WHERE AssocClass = Win32_LogicalDiskToPartition" -ErrorAction SilentlyContinue)
    if ($logicalDisks.Count -eq 0) {
      $rows += [pscustomobject]@{ Include=$false; ExcludeReason='Win32_LogicalDisk が存在しません'; Model=$model; InterfaceType=$interfaceType; MediaType=$mediaType; PNPDeviceID=$pnp; DeviceID=$diskDeviceID; PartitionDeviceID=[string]$partition.DeviceID; DiskSize=$diskSize }
      continue
    }
    foreach ($logical in $logicalDisks) {
      $driveType = [int]$logical.DriveType
      $filesystem = [string]$logical.FileSystem
      $driveLetter = [string]$logical.DeviceID
      $volumeLabel = [string]$logical.VolumeName
      $logicalSize = [string]$logical.Size

      if (-not $driveLetter) {
        $rows += [pscustomobject]@{ Include=$false; ExcludeReason='LogicalDisk.DeviceID が空です'; Model=$model; InterfaceType=$interfaceType; MediaType=$mediaType; PNPDeviceID=$pnp; DeviceID=$diskDeviceID; PartitionDeviceID=[string]$partition.DeviceID; DriveType=$driveType; FileSystem=$filesystem; VolumeName=$volumeLabel; Size=$logicalSize; DiskSize=$diskSize }
        continue
      }
      if (-not $filesystem) {
        $rows += [pscustomobject]@{ Include=$false; ExcludeReason='LogicalDisk.FileSystem が空です'; Model=$model; InterfaceType=$interfaceType; MediaType=$mediaType; PNPDeviceID=$pnp; DeviceID=$diskDeviceID; PartitionDeviceID=[string]$partition.DeviceID; DriveLetter=$driveLetter; DriveType=$driveType; FileSystem=$filesystem; VolumeName=$volumeLabel; Size=$logicalSize; DiskSize=$diskSize }
        continue
      }
      if ($driveType -eq 5) {
        $rows += [pscustomobject]@{ Include=$false; ExcludeReason='CD/DVD DriveType=5 のため除外'; Model=$model; InterfaceType=$interfaceType; MediaType=$mediaType; PNPDeviceID=$pnp; DeviceID=$diskDeviceID; PartitionDeviceID=[string]$partition.DeviceID; DriveLetter=$driveLetter; DriveType=$driveType; FileSystem=$filesystem; VolumeName=$volumeLabel; Size=$logicalSize; DiskSize=$diskSize }
        continue
      }
      if ($driveType -ne 2 -and $driveType -ne 3) {
        $rows += [pscustomobject]@{ Include=$false; ExcludeReason=("対象外 DriveType=" + $driveType); Model=$model; InterfaceType=$interfaceType; MediaType=$mediaType; PNPDeviceID=$pnp; DeviceID=$diskDeviceID; PartitionDeviceID=[string]$partition.DeviceID; DriveLetter=$driveLetter; DriveType=$driveType; FileSystem=$filesystem; VolumeName=$volumeLabel; Size=$logicalSize; DiskSize=$diskSize }
        continue
      }

      $serial = [string]$disk.SerialNumber
      if ($usePhysicalSerial) {
        $match = $media | Where-Object { $_.Tag -eq $disk.DeviceID } | Select-Object -First 1
        $serial = [string]$match.SerialNumber
      }
      if ($usePnpSerial) {
        $serial = ''
      }
      $rows += [pscustomobject]@{
        Include=$true
        SerialNumber=$serial
        Model=$model
        InterfaceType=$interfaceType
        MediaType=$mediaType
        PNPDeviceID=$pnp
        DeviceID=$diskDeviceID
        PartitionDeviceID=[string]$partition.DeviceID
        DriveLetter=$driveLetter
        DriveType=$driveType
        FileSystem=$filesystem
        VolumeName=$volumeLabel
        VolumeLabel=$volumeLabel
        Size=$logicalSize
        DiskSize=$diskSize
      }
    }
  }
}
$rows | ConvertTo-Json -Depth 5
"""
        return self._fill_script_placeholders(script, serial_source)

    def _cim_storage_script(self, serial_source: str) -> str:
        script = r"""
[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new()
$ErrorActionPreference = 'Stop'
$usePnpSerial = __USE_PNP__
$excludedPnpPattern = '__EXCLUDED_PNP_PATTERN__'
$rows = @()
$disks = Get-CimInstance Win32_DiskDrive -ErrorAction Stop
foreach ($disk in $disks) {
  $interfaceType = [string]$disk.InterfaceType
  $pnp = [string]$disk.PNPDeviceID
  $model = [string]$disk.Model
  $mediaType = [string]$disk.MediaType
  $diskSize = [string]$disk.Size
  $diskDeviceID = [string]$disk.DeviceID

  if ($interfaceType -ne 'USB') {
    $rows += [pscustomobject]@{ Include=$false; ExcludeReason='DiskDrive.InterfaceType が USB ではありません'; Model=$model; InterfaceType=$interfaceType; MediaType=$mediaType; PNPDeviceID=$pnp; DeviceID=$diskDeviceID; DiskSize=$diskSize }
    continue
  }
  if ($pnp -match $excludedPnpPattern) {
    $rows += [pscustomobject]@{ Include=$false; ExcludeReason='PNPDeviceID が HID/MOUSE/KEYBOARD/BLUETOOTH 系です'; Model=$model; InterfaceType=$interfaceType; MediaType=$mediaType; PNPDeviceID=$pnp; DeviceID=$diskDeviceID; DiskSize=$diskSize }
    continue
  }

  $partitions = @(Get-CimAssociatedInstance -InputObject $disk -Association Win32_DiskDriveToDiskPartition -ErrorAction SilentlyContinue)
  if ($partitions.Count -eq 0) {
    $rows += [pscustomobject]@{ Include=$false; ExcludeReason='Win32_DiskPartition が存在しません'; Model=$model; InterfaceType=$interfaceType; MediaType=$mediaType; PNPDeviceID=$pnp; DeviceID=$diskDeviceID; DiskSize=$diskSize }
    continue
  }
  foreach ($partition in $partitions) {
    $logicalDisks = @(Get-CimAssociatedInstance -InputObject $partition -Association Win32_LogicalDiskToPartition -ErrorAction SilentlyContinue)
    if ($logicalDisks.Count -eq 0) {
      $rows += [pscustomobject]@{ Include=$false; ExcludeReason='Win32_LogicalDisk が存在しません'; Model=$model; InterfaceType=$interfaceType; MediaType=$mediaType; PNPDeviceID=$pnp; DeviceID=$diskDeviceID; PartitionDeviceID=[string]$partition.DeviceID; DiskSize=$diskSize }
      continue
    }
    foreach ($logical in $logicalDisks) {
      $driveType = [int]$logical.DriveType
      $filesystem = [string]$logical.FileSystem
      $driveLetter = [string]$logical.DeviceID
      $volumeLabel = [string]$logical.VolumeName
      $logicalSize = [string]$logical.Size

      if (-not $driveLetter) {
        $rows += [pscustomobject]@{ Include=$false; ExcludeReason='LogicalDisk.DeviceID が空です'; Model=$model; InterfaceType=$interfaceType; MediaType=$mediaType; PNPDeviceID=$pnp; DeviceID=$diskDeviceID; PartitionDeviceID=[string]$partition.DeviceID; DriveType=$driveType; FileSystem=$filesystem; VolumeName=$volumeLabel; Size=$logicalSize; DiskSize=$diskSize }
        continue
      }
      if (-not $filesystem) {
        $rows += [pscustomobject]@{ Include=$false; ExcludeReason='LogicalDisk.FileSystem が空です'; Model=$model; InterfaceType=$interfaceType; MediaType=$mediaType; PNPDeviceID=$pnp; DeviceID=$diskDeviceID; PartitionDeviceID=[string]$partition.DeviceID; DriveLetter=$driveLetter; DriveType=$driveType; FileSystem=$filesystem; VolumeName=$volumeLabel; Size=$logicalSize; DiskSize=$diskSize }
        continue
      }
      if ($driveType -eq 5) {
        $rows += [pscustomobject]@{ Include=$false; ExcludeReason='CD/DVD DriveType=5 のため除外'; Model=$model; InterfaceType=$interfaceType; MediaType=$mediaType; PNPDeviceID=$pnp; DeviceID=$diskDeviceID; PartitionDeviceID=[string]$partition.DeviceID; DriveLetter=$driveLetter; DriveType=$driveType; FileSystem=$filesystem; VolumeName=$volumeLabel; Size=$logicalSize; DiskSize=$diskSize }
        continue
      }
      if ($driveType -ne 2 -and $driveType -ne 3) {
        $rows += [pscustomobject]@{ Include=$false; ExcludeReason=("対象外 DriveType=" + $driveType); Model=$model; InterfaceType=$interfaceType; MediaType=$mediaType; PNPDeviceID=$pnp; DeviceID=$diskDeviceID; PartitionDeviceID=[string]$partition.DeviceID; DriveLetter=$driveLetter; DriveType=$driveType; FileSystem=$filesystem; VolumeName=$volumeLabel; Size=$logicalSize; DiskSize=$diskSize }
        continue
      }

      $serial = if ($usePnpSerial) { '' } else { [string]$disk.SerialNumber }
      $rows += [pscustomobject]@{
        Include=$true
        SerialNumber=$serial
        Model=$model
        InterfaceType=$interfaceType
        MediaType=$mediaType
        PNPDeviceID=$pnp
        DeviceID=$diskDeviceID
        PartitionDeviceID=[string]$partition.DeviceID
        DriveLetter=$driveLetter
        DriveType=$driveType
        FileSystem=$filesystem
        VolumeName=$volumeLabel
        VolumeLabel=$volumeLabel
        Size=$logicalSize
        DiskSize=$diskSize
      }
    }
  }
}
$rows | ConvertTo-Json -Depth 5
"""
        return self._fill_script_placeholders(script, serial_source)

    def _fill_script_placeholders(self, script: str, serial_source: str) -> str:
        return (
            script.replace("__USE_PHYSICAL__", "$true" if serial_source == "physical" else "$false")
            .replace("__USE_PNP__", "$true" if serial_source == "pnp" else "$false")
            .replace("__EXCLUDED_PNP_PATTERN__", self.EXCLUDED_PNP_PATTERN)
        )

    def _rows_to_devices(self, rows: list[dict[str, Any]], source_method: str) -> list[USBDevice]:
        grouped: dict[str, dict[str, Any]] = {}
        for row in rows:
            if not bool(row.get("Include")):
                self._log_excluded_row(row, source_method)
                continue
            serial = self._normalize_serial(str(row.get("SerialNumber") or ""))
            if not serial and source_method == "PNPDeviceID解析":
                serial = self._parse_serial_from_pnp(str(row.get("PNPDeviceID") or ""))
            if not serial:
                self._log(
                    "[debug] USBストレージ除外: serial取得不可, "
                    f"method={source_method}, drive_letter={row.get('DriveLetter') or ''}, "
                    f"drive_type={row.get('DriveType') or ''}, filesystem={row.get('FileSystem') or ''}, "
                    f"model={row.get('Model') or ''}, pnp={row.get('PNPDeviceID') or ''}",
                    debug=True,
                )
                continue

            disk_key = str(row.get("DeviceID") or serial or row.get("PNPDeviceID") or "").strip()
            group = grouped.setdefault(
                disk_key,
                {
                    "serial": serial,
                    "model": str(row.get("Model") or "").strip(),
                    "pnp_device_id": str(row.get("PNPDeviceID") or "").strip(),
                    "device_id": str(row.get("DeviceID") or "").strip(),
                    "media_type": str(row.get("MediaType") or "").strip(),
                    "source_method": source_method,
                    "rows": [],
                    "partitions": [],
                },
            )
            partition = {
                "drive_letter": str(row.get("DriveLetter") or "").strip(),
                "filesystem": str(row.get("FileSystem") or "").strip(),
                "volume_label": str(row.get("VolumeLabel") or row.get("VolumeName") or "").strip(),
                "drive_type": self._to_int(row.get("DriveType")),
                "size": str(row.get("Size") or "").strip(),
            }
            partition_key = (partition["drive_letter"], partition["filesystem"])
            existing = {
                (item.get("drive_letter"), item.get("filesystem"))
                for item in group["partitions"]
            }
            if partition_key not in existing:
                group["partitions"].append(partition)
            group["rows"].append(row)

        devices: list[USBDevice] = []
        for group in grouped.values():
            partitions = group["partitions"]
            drive_letters = [item["drive_letter"] for item in partitions if item.get("drive_letter")]
            filesystems = [item["filesystem"] for item in partitions if item.get("filesystem")]
            volume_labels = [item["volume_label"] for item in partitions if item.get("volume_label")]
            drive_types = [item["drive_type"] for item in partitions if item.get("drive_type") is not None]
            devices.append(
                USBDevice(
                    serial=group["serial"],
                    model=group["model"],
                    pnp_device_id=group["pnp_device_id"],
                    device_id=group["device_id"],
                    drive_letter=", ".join(drive_letters),
                    volume_label=", ".join(volume_labels),
                    filesystem=", ".join(filesystems),
                    media_type=group["media_type"],
                    drive_type=drive_types[0] if drive_types else None,
                    partitions=partitions,
                    source_method=group["source_method"],
                    raw={"rows": group["rows"]},
                )
            )
        return devices

    def _log_excluded_row(self, row: dict[str, Any], source_method: str) -> None:
        self._log(
            "[debug] USBデバイス除外: "
            f"method={source_method}, reason={row.get('ExcludeReason') or '不明'}, "
            f"model={row.get('Model') or ''}, interface_type={row.get('InterfaceType') or ''}, "
            f"media_type={row.get('MediaType') or ''}, pnp={row.get('PNPDeviceID') or ''}, "
            f"drive={row.get('DriveLetter') or ''}, drive_type={row.get('DriveType') or ''}, "
            f"filesystem={row.get('FileSystem') or ''}, volume={row.get('VolumeName') or row.get('VolumeLabel') or ''}, "
            f"size={row.get('Size') or ''}",
            debug=True,
        )

    def _normalize_serial(self, value: str) -> str:
        cleaned = value.strip().strip(".").replace(" ", "")
        return cleaned.upper()

    def _parse_serial_from_pnp(self, pnp_device_id: str) -> str:
        if not pnp_device_id:
            return ""
        tail = pnp_device_id.split("\\")[-1]
        tail = tail.split("&")[0]
        tail = re.sub(r"[^A-Za-z0-9_-]", "", tail)
        return self._normalize_serial(tail)

    def _to_int(self, value: Any) -> int | None:
        try:
            return int(value)
        except (TypeError, ValueError):
            return None

    def _dedupe(self, devices: list[USBDevice]) -> list[USBDevice]:
        deduped: dict[str, USBDevice] = {}
        for device in devices:
            key = device.device_id or device.serial or device.pnp_device_id
            deduped.setdefault(key, device)
        return list(deduped.values())
