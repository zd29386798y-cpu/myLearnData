from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any


DEFAULT_PEPPER = "USB_INVENTORY_CHECK_20260519_CHANGE_ME"


@dataclass(slots=True)
class AppConfig:
    shared_folder: str = r".\incoming"
    local_fallback_folder: str = r".\outbox"
    output_folder: str = r".\reports"
    registry_path: str = r".\registry_template.csv"
    app_pepper: str = DEFAULT_PEPPER
    recent_days: int = 7
    tool_version: str = "1.0.0"
    debug_mode: bool = False

    @classmethod
    def load(cls, path: str | Path) -> "AppConfig":
        config_path = Path(path)
        if not config_path.exists():
            config_path.parent.mkdir(parents=True, exist_ok=True)
            config = cls()
            config.save(config_path)
            return config
        with config_path.open("r", encoding="utf-8") as f:
            data: dict[str, Any] = json.load(f)
        known = {field: data[field] for field in cls.__dataclass_fields__ if field in data}
        return cls(**known)

    def save(self, path: str | Path) -> None:
        config_path = Path(path)
        config_path.parent.mkdir(parents=True, exist_ok=True)
        with config_path.open("w", encoding="utf-8") as f:
            json.dump(asdict(self), f, ensure_ascii=False, indent=2)
