from __future__ import annotations

import hashlib
import json
import os
import tempfile
from datetime import date, timedelta
from pathlib import Path
from typing import Iterable

from .crypto_util import CryptoService
from .models import DecryptResult


CHECK_FILE_SUFFIX = ".usbcheck"


def serial_hash(serial: str) -> str:
    return hashlib.sha256(serial.strip().upper().encode("utf-8")).hexdigest()


class UsbCheckFileStore:
    def __init__(self, folder: str | Path) -> None:
        self.folder = Path(folder)

    def ensure_folder(self) -> None:
        self.folder.mkdir(parents=True, exist_ok=True)

    def check_write_access(self) -> None:
        self.ensure_folder()
        fd, temp_name = tempfile.mkstemp(prefix=".write_test_", dir=self.folder)
        os.close(fd)
        os.remove(temp_name)

    def save_encrypted(self, serial: str, checked_date: str, encrypted_payload: bytes) -> Path:
        self.ensure_folder()
        target = self.folder / f"USB_{serial_hash(serial)}{CHECK_FILE_SUFFIX}"
        envelope = {
            "format": "usbcheck-v1",
            "checked_date": checked_date,
            "payload": encrypted_payload.decode("ascii"),
        }
        fd, temp_name = tempfile.mkstemp(prefix=target.name + ".", suffix=".tmp", dir=self.folder)
        temp_path = Path(temp_name)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(envelope, f, ensure_ascii=False, indent=2)
                f.flush()
                os.fsync(f.fileno())
            os.replace(temp_path, target)
            return target
        finally:
            if temp_path.exists():
                temp_path.unlink()

    def iter_check_files(self) -> Iterable[Path]:
        if not self.folder.exists():
            return []
        return sorted(self.folder.glob(f"*{CHECK_FILE_SUFFIX}"))


def decrypt_file(path: Path, crypto: CryptoService, fallback_days: int = 14) -> DecryptResult:
    try:
        with path.open("r", encoding="utf-8") as f:
            envelope = json.load(f)
        payload = str(envelope["payload"]).encode("ascii")
        checked_date = str(envelope.get("checked_date", ""))
        dates_to_try = [checked_date] if checked_date else []
        today = date.today()
        dates_to_try.extend((today - timedelta(days=i)).strftime("%Y%m%d") for i in range(fallback_days + 1))
        seen: set[str] = set()
        for candidate in dates_to_try:
            if not candidate or candidate in seen:
                continue
            seen.add(candidate)
            try:
                record = crypto.decrypt_payload(payload, candidate)
                return DecryptResult(file_name=path.name, ok=True, record=record)
            except Exception as exc:
                last_error = str(exc) or exc.__class__.__name__
        return DecryptResult(file_name=path.name, ok=False, error=f"復号失敗: {last_error}")
    except Exception as exc:
        return DecryptResult(file_name=path.name, ok=False, error=f"読込失敗: {exc}")

