from __future__ import annotations

import base64
import hashlib
import json
from typing import Any

from cryptography.fernet import Fernet


class CryptoService:
    def __init__(self, app_pepper: str) -> None:
        self.app_pepper = app_pepper

    def derive_key(self, checked_date: str) -> bytes:
        material = (self.app_pepper + checked_date).encode("utf-8")
        digest = hashlib.sha256(material).digest()
        return base64.urlsafe_b64encode(digest)

    def encrypt_record(self, record: dict[str, Any]) -> bytes:
        checked_date = str(record["checked_date"])
        payload = json.dumps(record, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        return Fernet(self.derive_key(checked_date)).encrypt(payload)

    def decrypt_payload(self, encrypted: bytes, checked_date: str) -> dict[str, Any]:
        decrypted = Fernet(self.derive_key(checked_date)).decrypt(encrypted)
        return json.loads(decrypted.decode("utf-8"))

