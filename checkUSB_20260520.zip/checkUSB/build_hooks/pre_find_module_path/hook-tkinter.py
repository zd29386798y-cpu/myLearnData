def pre_find_module_path(hook_api):
    # The bundled Python used in this workspace can import tkinter normally,
    # but PyInstaller's isolated Tcl/Tk probe may fail and exclude tkinter.
    # Keep module discovery enabled; Tcl/Tk files are added explicitly by bat.
    return
